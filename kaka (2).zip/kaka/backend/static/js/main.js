
/* ======================================================
   SCROLL REVEAL — run first so animations are ready
   ====================================================== */
(function () {
  // Enable CSS animations (hides .reveal elements until in view)
  document.documentElement.classList.add('js-reveal');

  const obs = new IntersectionObserver((entries) => {
    entries.forEach(en => {
      if (en.isIntersecting) {
        en.target.classList.add('in');
        obs.unobserve(en.target);
      }
    });
  }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });

  function observe() {
    document.querySelectorAll('.reveal, .reveal-stagger').forEach(el => obs.observe(el));
  }

  // Observe now + after dynamic content renders
  document.addEventListener('DOMContentLoaded', () => {
    observe();
    // Re-observe after dynamic content is rendered (services, stack, projects etc.)
    setTimeout(observe, 1200);
  });
})();

/* ======================================================
   I18N
   ====================================================== */
const i18n = {
  en: {
    'nav.about': 'About', 'nav.services': 'Services', 'nav.work': 'Work', 'nav.process': 'Process', 'nav.reviews': 'Reviews', 'nav.faq': 'FAQ', 'nav.contact': 'Contact', 'nav.hire': 'Hire Me',
    'hero.greet': "Hi, I'm", 'hero.desc': "I build modern websites, powerful web applications, AI systems, Telegram bots, mobile apps and business automation solutions.",
    'hero.hire': 'Hire Me', 'hero.consult': 'Get Free Consultation', 'hero.portfolio': 'View Portfolio',
    'hero.stat1': 'Projects', 'hero.stat2': 'Client Satisfaction', 'hero.stat3': 'Support', 'hero.stat4': 'Fast Delivery',
    'about.title': "Engineering products, not just code", 'about.sub': "A quick look at how I work, what I've built, and where I'm headed next.",
    'about.cv': 'Download CV',
    'about.p1': "For the past seven years I've worked at the intersection of design, engineering and AI — taking ideas from a single sentence on a discovery call to production systems used by real customers.",
    'about.p2': "I started out building landing pages for local businesses, then spent several years inside fast-moving product teams shipping web platforms, mobile apps and internal tools. Today I run an independent practice that partners directly with founders and operations leads who need software built fast, built right, and built to last.",
    'about.mission': 'Turn ambitious ideas into reliable, scalable software — without the agency overhead.',
    'about.vision': 'To be the long-term technical partner founders call before they call anyone else.',
    'services.title': 'What I can build for you', 'services.sub': "From a single landing page to a full AI-powered platform — pick what you need, or let's scope it together.",
    'stack.title': 'Tools I trust in production', 'stack.sub': 'A modern, battle-tested stack chosen for speed, reliability and long-term maintainability.',
    'work.title': 'Selected work', 'work.sub': 'A snapshot of recent projects across web, mobile, AI and automation.',
    'process.title': 'How a project moves forward', 'process.sub': 'A clear, predictable process — six stages, no surprises.',
    'why.title': "Built for founders who can't afford delays",
    'rev.title': 'What clients say',
    'faq.title': 'Common questions',
    'call.title': "Let's talk through your idea", 'call.sub': 'A free 30-minute call to discuss scope, timeline and budget — no pressure, no obligation.', 'call.cta': 'Confirm Booking',
    'contact.title': 'Tell me about your project', 'contact.sub': "Fill in the details and I'll get back to you within 24 hours with next steps.",
    'contact.p': 'Prefer a quick message instead? Reach out directly — I personally read and answer every inquiry.'
  },
  ru: {
    'nav.about': 'Обо мне', 'nav.services': 'Услуги', 'nav.work': 'Работы', 'nav.process': 'Процесс', 'nav.reviews': 'Отзывы', 'nav.faq': 'Вопросы', 'nav.contact': 'Контакты', 'nav.hire': 'Нанять',
    'hero.greet': 'Привет, я', 'hero.desc': 'Я создаю современные сайты, мощные веб-приложения, AI-системы, Telegram-ботов, мобильные приложения и решения для автоматизации бизнеса.',
    'hero.hire': 'Нанять меня', 'hero.consult': 'Бесплатная консультация', 'hero.portfolio': 'Смотреть портфолио',
    'hero.stat1': 'Проектов', 'hero.stat2': 'Довольных клиентов', 'hero.stat3': 'Поддержка', 'hero.stat4': 'Быстрая сдача',
    'about.title': 'Я создаю продукты, а не просто код', 'about.sub': 'Коротко о том, как я работаю, что я создал и куда двигаюсь дальше.',
    'about.cv': 'Скачать резюме',
    'about.p1': 'Последние семь лет я работаю на стыке дизайна, разработки и AI — превращая идею с созвона в работающую систему для реальных клиентов.',
    'about.p2': 'Начинал с лендингов для локального бизнеса, затем несколько лет работал в продуктовых командах, выпуская веб-платформы, мобильные приложения и внутренние инструменты. Сейчас я веду независимую практику и работаю напрямую с фаундерами по всему миру.',
    'about.mission': 'Превращать амбициозные идеи в надёжное, масштабируемое ПО — без накладных расходов агентства.',
    'about.vision': 'Стать долгосрочным техническим партнёром, к которому обращаются в первую очередь.',
    'services.title': 'Что я могу для вас создать', 'services.sub': 'От лендинга до полноценной платформы с AI — выберите нужное, или обсудим вместе.',
    'stack.title': 'Технологии, которым я доверяю', 'stack.sub': 'Современный, проверенный стек для скорости, надёжности и удобной поддержки.',
    'work.title': 'Избранные проекты', 'work.sub': 'Недавние проекты в сфере веба, мобильной разработки, AI и автоматизации.',
    'process.title': 'Как продвигается проект', 'process.sub': 'Понятный, предсказуемый процесс — шесть этапов, никаких сюрпризов.',
    'why.title': 'Для фаундеров, которым важна скорость',
    'rev.title': 'Отзывы клиентов',
    'faq.title': 'Частые вопросы',
    'call.title': 'Обсудим вашу идею', 'call.sub': 'Бесплатный 30-минутный звонок про объём работ, сроки и бюджет — без давления.', 'call.cta': 'Подтвердить звонок',
    'contact.title': 'Расскажите о своём проекте', 'contact.sub': 'Заполните форму, и я отвечу в течение 24 часов.',
    'contact.p': 'Хотите написать напрямую? Я лично читаю и отвечаю на каждое сообщение.'
  },
  uz: {
    'nav.about': 'Men haqimda', 'nav.services': 'Xizmatlar', 'nav.work': 'Loyihalar', 'nav.process': 'Jarayon', 'nav.reviews': 'Sharhlar', 'nav.faq': 'Savollar', 'nav.contact': 'Aloqa', 'nav.hire': 'Ishga olish',
    'hero.greet': 'Salom, men', 'hero.desc': "Men zamonaviy saytlar, kuchli veb-ilovalar, AI tizimlari, Telegram botlar, mobil ilovalar va biznes avtomatlashtirish yechimlarini yarataman.",
    'hero.hire': 'Meni yollang', 'hero.consult': 'Bepul konsultatsiya', 'hero.portfolio': 'Portfolioni ko\'rish',
    'hero.stat1': 'Loyihalar', 'hero.stat2': 'Mijozlar mamnun', 'hero.stat3': 'Qo\'llab-quvvatlash', 'hero.stat4': 'Tez yetkazib berish',
    'about.title': "Mahsulot yarataman, shunchaki kod emas", 'about.sub': "Qanday ishlashim, nima yaratganim va keyingi rejalarim haqida qisqacha.",
    'about.cv': 'CV yuklab olish',
    'about.p1': "So'nggi yetti yil davomida dizayn, dasturlash va sun'iy intellekt chorrahasida ishlab kelmoqdaman — g'oyani real mijozlar foydalanadigan tizimga aylantiraman.",
    'about.p2': "Mahalliy bizneslar uchun landing sahifalardan boshladim, keyin bir necha yil mahsulot jamoalarida veb-platformalar va mobil ilovalar yaratdim. Hozir butun dunyo bo'ylab asoschilar bilan to'g'ridan-to'g'ri ishlayman.",
    'about.mission': "Jasur g'oyalarni ishonchli, kengaytiriladigan dasturiy ta'minotga aylantirish — agentlik xarajatlarisiz.",
    'about.vision': "Asoschilar birinchi navbatda murojaat qiladigan uzoq muddatli texnik hamkor bo'lish.",
    'services.title': 'Siz uchun nima yarata olaman', 'services.sub': "Oddiy landing sahifadan to to'liq AI platformasigacha — kerakli narsani tanlang.",
    'stack.title': 'Ishonadigan texnologiyalarim', 'stack.sub': "Tezlik, ishonchlilik va qo'llab-quvvatlash uchun tanlangan zamonaviy stack.",
    'work.title': 'Tanlangan loyihalar', 'work.sub': "Veb, mobil, AI va avtomatlashtirish sohasidagi so'nggi loyihalar.",
    'process.title': 'Loyiha qanday rivojlanadi', 'process.sub': "Aniq va bashorat qilinadigan jarayon — olti bosqich, hech qanday sarprizsiz.",
    'why.title': "Kechikishga vaqti yo'q asoschilar uchun",
    'rev.title': 'Mijozlar fikri',
    'faq.title': "Ko'p so'raladigan savollar",
    'call.title': "G'oyangizni muhokama qilaylik", 'call.sub': "Qamrov, muddat va byudjet bo'yicha bepul 30 daqiqalik qo'ng'iroq.", 'call.cta': "Qo'ng'iroqni tasdiqlash",
    'contact.title': 'Loyihangiz haqida ayting', 'contact.sub': "Formani to'ldiring, 24 soat ichida javob beraman.",
    'contact.p': "To'g'ridan-to'g'ri yozishni xohlaysizmi? Har bir murojaatni shaxsan o'qiyman."
  }
};
let currentLang = 'en';
async function setLang(lang) {
  currentLang = lang;
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    const dict = i18n[lang] || i18n.en;
    if (dict[key]) {
      el.classList.add('lang-fade');
      setTimeout(() => { el.textContent = dict[key]; el.classList.remove('lang-fade'); }, 150);
    }
  });
  document.querySelectorAll('#lang-switch button').forEach(b => b.classList.toggle('active', b.dataset.lang === lang));
  await fetchDynamicData(lang);
}
document.getElementById('lang-switch').addEventListener('click', e => {
  const btn = e.target.closest('button'); if (!btn) return;
  setLang(btn.dataset.lang);
});



/* ======================================================
   CURSOR
   ====================================================== */
const cdot = document.getElementById('cdot'), cring = document.getElementById('cring');
let mx = 0, my = 0, rx = 0, ry = 0;
window.addEventListener('mousemove', e => {
  mx = e.clientX; my = e.clientY;
  cdot.style.left = mx + 'px'; cdot.style.top = my + 'px';
});
function ringLoop() { rx += (mx - rx) * 0.18; ry += (my - ry) * 0.18; cring.style.left = rx + 'px'; cring.style.top = ry + 'px'; requestAnimationFrame(ringLoop); }
ringLoop();
document.querySelectorAll('a,button,.svc-card,.proj-card,input,select,textarea,.tech-badge,.faq-q,.slot,.mini-cal span.avail').forEach(el => {
  el.addEventListener('mouseenter', () => cring.classList.add('active'));
  el.addEventListener('mouseleave', () => cring.classList.remove('active'));
});

/* ======================================================
   NAV: scroll state, mobile menu
   ====================================================== */
const header = document.getElementById('site-header');
window.addEventListener('scroll', () => {
  header.classList.toggle('scrolled', window.scrollY > 40);
  document.getElementById('back-top').classList.toggle('show', window.scrollY > 700);
});
const mmenu = document.getElementById('mobile-menu');
document.getElementById('burger-btn').addEventListener('click', () => mmenu.classList.add('open'));
document.getElementById('mclose').addEventListener('click', () => mmenu.classList.remove('open'));
mmenu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => mmenu.classList.remove('open')));
document.getElementById('back-top').addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

/* ======================================================
   HERO ROLE TYPEWRITER
   ====================================================== */
const roles = ['Full Stack Developer', 'AI Engineer', 'Mobile App Developer', 'Automation Specialist'];
const roleEl = document.getElementById('role-text');
let ri = 0, ci = 0, deleting = false;
function typeLoop() {
  const word = roles[ri];
  if (!deleting) {
    ci++; roleEl.textContent = word.slice(0, ci);
    if (ci === word.length) { deleting = true; setTimeout(typeLoop, 1400); return; }
  } else {
    ci--; roleEl.textContent = word.slice(0, ci);
    if (ci === 0) { deleting = false; ri = (ri + 1) % roles.length; }
  }
  setTimeout(typeLoop, deleting ? 35 : 65);
}
typeLoop();

/* ======================================================
   TERMINAL CODE TYPING
   ====================================================== */
const termLines = [
  '<span class="tk-key">const</span> <span class="tk-prop">developer</span> <span class="tk-punc">=</span> <span class="tk-punc">{</span>',
  '&nbsp;&nbsp;<span class="tk-prop">name</span><span class="tk-punc">:</span> <span class="tk-str">"Ulugbek Xasanov"</span><span class="tk-punc">,</span>',
  '&nbsp;&nbsp;<span class="tk-prop">role</span><span class="tk-punc">:</span> <span class="tk-str">"Full Stack Developer"</span><span class="tk-punc">,</span>',
  '&nbsp;&nbsp;<span class="tk-prop">stack</span><span class="tk-punc">:</span> <span class="tk-punc">[</span><span class="tk-str">"React"</span><span class="tk-punc">,</span> <span class="tk-str">"Next.js"</span><span class="tk-punc">,</span> <span class="tk-str">"Python"</span><span class="tk-punc">,</span> <span class="tk-str">"Django"</span><span class="tk-punc">],</span>',
  '&nbsp;&nbsp;<span class="tk-prop">focus</span><span class="tk-punc">:</span> <span class="tk-punc">[</span><span class="tk-str">"AI Systems"</span><span class="tk-punc">,</span> <span class="tk-str">"Automation"</span><span class="tk-punc">,</span> <span class="tk-str">"Mobile Apps"</span><span class="tk-punc">],</span>',
  '&nbsp;&nbsp;<span class="tk-prop">status</span><span class="tk-punc">:</span> <span class="tk-str">"Available for projects"</span><span class="tk-punc">,</span>',
  '<span class="tk-punc">};</span>',
  '&nbsp;',
  '<span class="tk-fn">deploy</span><span class="tk-punc">(</span><span class="tk-prop">developer</span><span class="tk-punc">.</span><span class="tk-prop">skills</span><span class="tk-punc">);</span>',
  '<span class="tk-com">// → Building products that scale.</span>'
];
const termBody = document.getElementById('term-body');
let tLine = 0;
function typeTerminal() {
  if (tLine >= termLines.length) {
    const c = document.createElement('span'); c.className = 'term-cursor'; termBody.appendChild(c); return;
  }
  const row = document.createElement('div');
  row.innerHTML = '<span class="ln">' + String(tLine + 1).padStart(2, '0') + '</span>' + termLines[tLine];
  termBody.appendChild(row);
  tLine++;
  setTimeout(typeTerminal, 220);
}
setTimeout(typeTerminal, 900);

/* terminal tilt on mouse */
const termWrap = document.querySelector('.terminal-wrap');
const term = document.querySelector('.terminal');
if (termWrap) {
  termWrap.addEventListener('mousemove', e => {
    const r = termWrap.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5, py = (e.clientY - r.top) / r.height - 0.5;
    term.style.transform = `rotateY(${-8 + px * 10}deg) rotateX(${4 - py * 10}deg)`;
  });
  termWrap.addEventListener('mouseleave', () => { term.style.transform = 'rotateY(-8deg) rotateX(4deg)'; });
}

/* ======================================================
   HERO CANVAS PARTICLE NETWORK
   ====================================================== */
(function () {
  const canvas = document.getElementById('hero-canvas');
  const ctx = canvas.getContext('2d');
  let w, h, particles = [];
  const heroSection = document.querySelector('.hero');
  function resize() { w = canvas.width = heroSection.offsetWidth; h = canvas.height = heroSection.offsetHeight; }
  function init() {
    resize();
    const count = Math.min(60, Math.floor(w / 26));
    particles = Array.from({ length: count }, () => ({
      x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - 0.5) * 0.35, vy: (Math.random() - 0.5) * 0.35, r: Math.random() * 1.6 + 0.6
    }));
  }
  let running = true;
  function draw() {
    if (!running) { requestAnimationFrame(draw); return; }
    ctx.clearRect(0, 0, w, h);
    for (const p of particles) {
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0 || p.x > w) p.vx *= -1;
      if (p.y < 0 || p.y > h) p.vy *= -1;
    }
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const a = particles[i], b = particles[j];
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        if (d < 150) {
          ctx.strokeStyle = `rgba(111,168,255,${0.14 * (1 - d / 150)})`;
          ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
        }
      }
    }
    for (const p of particles) {
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(200,155,255,0.55)'; ctx.fill();
    }
    requestAnimationFrame(draw);
  }
  window.addEventListener('resize', resize);
  new IntersectionObserver((entries) => { running = entries[0].isIntersecting; }, { threshold: 0 }).observe(heroSection);
  init(); draw();
})();

/* ======================================================
   SCROLL REVEAL
   ====================================================== */
const revealObs = new IntersectionObserver((entries) => {
  entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add('in'); revealObs.unobserve(en.target); } });
}, { threshold: 0.15 });
document.querySelectorAll('.reveal, .reveal-stagger').forEach(el => revealObs.observe(el));

/* skill bars */
const skillObs = new IntersectionObserver((entries) => {
  entries.forEach(en => {
    if (en.isIntersecting) {
      en.target.querySelectorAll('.skill-fill').forEach(f => { f.style.width = f.dataset.w + '%'; });
      skillObs.unobserve(en.target);
    }
  });
}, { threshold: 0.3 });
const skillsBlock = document.querySelector('.skills');
if (skillsBlock) skillObs.observe(skillsBlock);

/* ======================================================
   DATA: SERVICES & FALLBACKS
   ====================================================== */
const fallbackServices = [
  { icon: 'globe', title: 'Web Development', desc: 'Fast, accessible websites built to convert visitors into customers.', tags: ['Landing Pages', 'Corporate Sites', 'Online Stores', 'CMS'] },
  { icon: 'layers', title: 'Web Apps & SaaS', desc: 'Custom platforms for complex business logic and internal tools.', tags: ['CRM', 'ERP', 'Dashboards', 'Multi-tenant SaaS'] },
  { icon: 'phone', title: 'Mobile Apps', desc: 'Native-feel apps for iOS & Android from a single codebase.', tags: ['Flutter', 'React Native', 'App Store Launch'] },
  { icon: 'server', title: 'Backend & APIs', desc: 'The systems and APIs that keep everything running reliably.', tags: ['Django', 'FastAPI', 'REST / GraphQL', 'Microservices'] },
  { icon: 'cpu', title: 'AI & Automation', desc: 'Put AI to work inside your business — chat, data, workflows.', tags: ['OpenAI', 'Gemini', 'Custom Agents', 'Workflow Automation'] },
  { icon: 'send', title: 'Telegram Bots', desc: 'Bots that sell, support customers and automate operations.', tags: ['Payment Bots', 'Support Bots', 'Mini Apps'] },
  { icon: 'database', title: 'Database & Cloud', desc: 'Infrastructure and data design that scales with your growth.', tags: ['PostgreSQL', 'Docker', 'AWS / GCP', 'CI / CD'] },
  { icon: 'shield', title: 'Optimization & Security', desc: 'Faster, safer, and easier for customers to find and trust.', tags: ['SEO', 'Performance Audits', 'Hardening', 'Maintenance'] }
];
let dynamicServices = [...fallbackServices];

const icons = {
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 010 18 14 14 0 010-18z"/>',
  layers: '<path d="M12 2l9 5-9 5-9-5 9-5z"/><path d="M3 12l9 5 9-5"/><path d="M3 17l9 5 9-5"/>',
  phone: '<rect x="6" y="2" width="12" height="20" rx="2"/><path d="M11 18h2"/>',
  server: '<rect x="2" y="3" width="20" height="7" rx="1.5"/><rect x="2" y="14" width="20" height="7" rx="1.5"/><path d="M6 6.5h.01M6 17.5h.01"/>',
  cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/>',
  send: '<path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/>',
  database: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.66 3.58 3 8 3s8-1.34 8-3V5"/><path d="M4 12c0 1.66 3.58 3 8 3s8-1.34 8-3"/>',
  shield: '<path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z"/>'
};
function svgIcon(name, w = 22) { return `<svg width="${w}" height="${w}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${icons[name]}</svg>`; }

function renderServices() {
  const svcGrid = document.getElementById('services-grid');
  if (!svcGrid) return;
  svcGrid.innerHTML = '';
  dynamicServices.forEach(s => {
    svcGrid.insertAdjacentHTML('beforeend', `
      <div class="glass svc-card" onmousemove="svcMove(event,this)">
        <div class="svc-icon">${svgIcon(s.icon, 20)}</div>
        <h3>${s.title}</h3>
        <p>${s.desc}</p>
        <div class="tag-row">${s.tags.map(t => `<span class="tag">${t}</span>`).join('')}</div>
      </div>`);
  });
  // Add hover effect listener again to ring cursor
  svcGrid.querySelectorAll('.svc-card').forEach(el => {
    el.addEventListener('mouseenter', () => cring.classList.add('active'));
    el.addEventListener('mouseleave', () => cring.classList.remove('active'));
  });
}

function svcMove(e, el) {
  const r = el.getBoundingClientRect();
  el.style.setProperty('--mx', (e.clientX - r.left) + 'px');
  el.style.setProperty('--my', (e.clientY - r.top) + 'px');
}

/* ======================================================
   DATA: STACK & FALLBACKS
   ====================================================== */
const fallbackStack = [
  { cat: 'Frontend', color: '#6fa8ff', items: ['React', 'Next.js', 'TypeScript', 'TailwindCSS', 'HTML5', 'CSS3', 'JavaScript'] },
  { cat: 'Backend', color: '#34e3a1', items: ['Python', 'Django', 'FastAPI', 'Node.js', 'Express'] },
  { cat: 'Databases', color: '#ffc94d', items: ['PostgreSQL', 'MySQL', 'MongoDB', 'Redis'] },
  { cat: 'Cloud & DevOps', color: '#c89bff', items: ['Docker', 'NGINX', 'Linux', 'Git / GitHub', 'AWS', 'Google Cloud', 'Firebase'] },
  { cat: 'AI', color: '#ff9be0', items: ['OpenAI', 'Gemini', 'Claude', 'TensorFlow'] }
];
let dynamicStack = [...fallbackStack];

function renderStack() {
  const stackContainer = document.getElementById('stack-container');
  if (!stackContainer) return;
  stackContainer.innerHTML = '';
  dynamicStack.forEach(s => {
    stackContainer.insertAdjacentHTML('beforeend', `
      <div class="stack-cat reveal">
        <h3>${s.cat}</h3>
        <div class="stack-row">
          ${s.items.map(i => `<div class="glass tech-badge"><span class="tech-dot" style="background:${s.color};box-shadow:0 0 8px 1px ${s.color}"></span>${i}</div>`).join('')}
        </div>
      </div>`);
  });
  // Re-observe stack categories
  stackContainer.querySelectorAll('.stack-cat.reveal').forEach(el => revealObs.observe(el));
  // Add hover effect listener again to ring cursor
  stackContainer.querySelectorAll('.tech-badge').forEach(el => {
    el.addEventListener('mouseenter', () => cring.classList.add('active'));
    el.addEventListener('mouseleave', () => cring.classList.remove('active'));
  });
}

/* ======================================================
   DATA: PORTFOLIO PROJECTS & FALLBACKS
   ====================================================== */
const fallbackProjects = [
  {
    cat: 'Web App', name: 'Nexus CRM', desc: 'AI-assisted sales CRM with pipeline automation and forecasting.', img: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop&q=75', colors: ['#3b7cff', '#6c3df0'],
    tech: ['Next.js', 'Django', 'PostgreSQL', 'OpenAI'], features: ['Lead scoring with AI', 'Automated follow-up emails', 'Real-time pipeline dashboard', 'Role-based team access'],
    quote: 'Our sales team finally has visibility we never had before. Ulugbek delivered ahead of schedule.', client: 'Daniel Kim, CTO'
  },
  {
    cat: 'Mobile App', name: 'PayFlow', desc: 'Cross-platform fintech app for invoicing and instant payouts.', img: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=800&auto=format&fit=crop&q=75', colors: ['#34e3a1', '#3b7cff'],
    tech: ['Flutter', 'FastAPI', 'PostgreSQL', 'Stripe'], features: ['Biometric login', 'Instant payout tracking', 'Push notifications', 'Offline-first sync'],
    quote: 'The app feels native on both platforms — our users can\'t tell it was built from one codebase.', client: 'Marta Rossi, Operations Lead'
  },
  {
    cat: 'AI / Automation', name: 'TelegramAI Concierge', desc: 'AI-powered Telegram bot handling bookings and support for a hospitality brand.', img: 'https://images.unsplash.com/photo-1611746872915-64382b5c76da?w=800&auto=format&fit=crop&q=75', colors: ['#9b5cff', '#ff9be0'],
    tech: ['Python', 'Telegram Bot API', 'Gemini', 'Redis'], features: ['Natural language booking', 'Multi-language replies', 'Live handoff to staff', 'Analytics dashboard'],
    quote: 'Support response time dropped from hours to seconds. Guests love it.', client: 'Aisha Bello, Founder'
  },
  {
    cat: 'Website', name: 'Solis Studio', desc: 'High-conversion marketing site for a boutique architecture studio.', img: 'https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=800&auto=format&fit=crop&q=75', colors: ['#6fa8ff', '#c89bff'],
    tech: ['Next.js', 'TailwindCSS', 'Framer Motion'], features: ['Custom case study layouts', 'CMS-driven projects page', '98+ Lighthouse score', 'Multi-language content'],
    quote: 'Inquiries doubled within the first month of launch.', client: 'James Carter, Product Manager'
  },
  {
    cat: 'Web App', name: 'Orbit ERP', desc: 'Inventory and operations ERP for a multi-branch retail business.', img: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=75', colors: ['#3b7cff', '#34e3a1'],
    tech: ['Django', 'React', 'PostgreSQL', 'Docker'], features: ['Multi-branch inventory sync', 'Automated reordering rules', 'Role-based permissions', 'Exportable reports'],
    quote: 'We replaced three disconnected spreadsheets with one system that just works.', client: 'Daniel Kim, CTO'
  },
  {
    cat: 'AI / Automation', name: 'Atlas Automation Suite', desc: 'Internal workflow automation connecting CRM, email and Slack.', img: 'https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?w=800&auto=format&fit=crop&q=75', colors: ['#ff9be0', '#6c3df0'],
    tech: ['Python', 'FastAPI', 'OpenAI', 'Zapier-style workflows'], features: ['No-code rule builder', 'AI-drafted replies', 'Slack & email integration', 'Audit log'],
    quote: 'It quietly saves our ops team about ten hours a week.', client: 'Marta Rossi, Operations Lead'
  }
];
let dynamicProjects = [...fallbackProjects];

const filters = ['All', 'Website', 'Web App', 'Mobile App', 'AI / Automation'];
const filterRow = document.getElementById('filter-row');
filters.forEach((f, i) => {
  filterRow.insertAdjacentHTML('beforeend', `<button class="filter-btn ${i === 0 ? 'active' : ''}" data-f="${f}">${f}</button>`);
});
const projGrid = document.getElementById('proj-grid');
function renderProjects(filter) {
  projGrid.innerHTML = '';
  dynamicProjects.filter(p => filter === 'All' || p.cat === filter).forEach((p, idx) => {
    projGrid.insertAdjacentHTML('beforeend', `
      <div class="glass proj-card" data-idx="${dynamicProjects.indexOf(p)}">
        <div class="proj-visual" style="background:#0b0b15;overflow:hidden">
          <img src="${p.img}" alt="${p.name}" loading="lazy" style="width:100%;height:100%;object-fit:cover;transition:transform .8s cubic-bezier(.16,1,.3,1);">
          <div style="position:absolute;inset:0;background:linear-gradient(180deg,transparent 40%,rgba(7,7,12,.85));display:flex;align-items:flex-end;padding:14px;opacity:0;transition:opacity .4s;" class="proj-overlay">
            <div style="display:flex;flex-wrap:wrap;gap:6px;">${p.tech.map(t => `<span style="font-family:var(--font-mono);font-size:.62rem;padding:3px 9px;border-radius:100px;background:rgba(59,124,255,.3);border:1px solid rgba(111,168,255,.35);color:#6fa8ff;">${t}</span>`).join('')}</div>
          </div>
        </div>
        <div class="proj-body">
          <div class="cat">${p.cat}</div>
          <h3>${p.name}</h3>
          <p>${p.desc}</p>
          <span class="btn-link">View Details <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></span>
        </div>
      </div>`);
  });
  projGrid.querySelectorAll('.proj-card').forEach(c => {
    c.addEventListener('mouseenter', () => cring.classList.add('active'));
    c.addEventListener('mouseleave', () => cring.classList.remove('active'));
    c.addEventListener('click', () => openProjectModal(dynamicProjects[c.dataset.idx]));
  });
}

filterRow.addEventListener('click', e => {
  const btn = e.target.closest('.filter-btn'); if (!btn) return;
  filterRow.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderProjects(btn.dataset.f);
});

const modalOverlay = document.getElementById('modal-overlay');
const modalContent = document.getElementById('modal-content');
function openProjectModal(p) {
  modalContent.innerHTML = `
    <button class="modal-close" onclick="closeModal()">&times;</button>
    <span class="cat">${p.cat}</span>
    <h3>${p.name}</h3>
    <p class="desc">${p.desc}</p>
    <div class="tag-row" style="margin-bottom:22px">${p.tech.map(t => `<span class="tag">${t}</span>`).join('')}</div>
    <ul class="feat-grid">${p.features.map(f => `<li><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12l4 4L19 6"/></svg>${f}</li>`).join('')}</ul>
    <div class="quote">"${p.quote}"<cite>— ${p.client}</cite></div>
    <div class="btn-row">
      <a href="${p.live_demo_url || '#'}" class="btn btn-primary btn-sm"${p.live_demo_url ? ' target="_blank"' : ''}>Live Demo</a>
      <a href="${p.github_url || '#'}" class="btn btn-ghost btn-sm"${p.github_url ? ' target="_blank"' : ''}>View on GitHub</a>
    </div>`;
  modalOverlay.classList.add('open');
}
function closeModal() { modalOverlay.classList.remove('open'); }
modalOverlay.addEventListener('click', e => { if (e.target === modalOverlay) closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

/* ======================================================
   PROCESS
   ====================================================== */
const processSteps = [
  { n: '01', t: 'Discovery', d: 'Understand your goals, users and constraints on a free call.' },
  { n: '02', t: 'Planning', d: 'Scope, architecture and timeline, locked in writing.' },
  { n: '03', t: 'Design', d: 'Wireframes → high-fidelity UI you approve before code starts.' },
  { n: '04', t: 'Development', d: 'Agile sprints with weekly progress demos.' },
  { n: '05', t: 'Testing', d: 'Cross-device QA, performance and security checks.' },
  { n: '06', t: 'Launch', d: 'Deployment, monitoring, and a smooth handover.' }
];
const processRow = document.getElementById('process-row');
processSteps.forEach(s => {
  processRow.insertAdjacentHTML('beforeend', `
    <div class="proc-step"><div class="pnum">${s.n}</div><h4>${s.t}</h4><p>${s.d}</p></div>`);
});

/* ======================================================
   WHY CHOOSE ME
   ====================================================== */
const why = [
  { icon: 'send', t: 'Fast communication', d: 'Same-day replies, clear updates, no chasing for status.' },
  { icon: 'cpu', t: 'Modern technologies', d: 'A current, future-proof stack — not legacy patchwork.' },
  { icon: 'layers', t: 'Clean, maintainable code', d: 'Code the next developer can actually read and extend.' },
  { icon: 'globe', t: 'SEO-optimized by default', d: 'Built to be found, not bolted on after launch.' },
  { icon: 'shield', t: 'Secure by design', d: 'Authentication, validation and best practices from day one.' },
  { icon: 'phone', t: 'Fully responsive', d: 'Looks and works great on every device and screen.' },
  { icon: 'server', t: 'Built to scale', d: 'Architecture that holds up as your user base grows.' },
  { icon: 'database', t: 'Transparent, fair pricing', d: 'No hidden fees — you know the cost before we start.' },
  { icon: 'globe', t: 'Long-term support', d: 'I stay reachable after launch, not just until invoice.' }
];
const whyGrid = document.getElementById('why-grid');
why.forEach(w => {
  whyGrid.insertAdjacentHTML('beforeend', `
    <div class="glass why-card"><div class="why-icon">${svgIcon(w.icon, 18)}</div><div><h4>${w.t}</h4><p>${w.d}</p></div></div>`);
});

/* ======================================================
   TESTIMONIALS SLIDER & FALLBACKS
   ====================================================== */
const fallbackTestimonials = [
  { name: 'Aisha Bello', role: 'Founder, Lagos', quote: 'Ulugbek didn\'t just build what we asked for — he asked the right questions and shipped something better.', init: 'AB', colors: ['#3b7cff', '#6c3df0'] },
  { name: 'Daniel Kim', role: 'CTO, Seoul', quote: 'Clean code, clear communication, and he hit every milestone. Exactly what a fast-moving team needs.', init: 'DK', colors: ['#34e3a1', '#3b7cff'] },
  { name: 'Marta Rossi', role: 'Operations Lead, Milan', quote: 'The automation alone paid for the project within two months. Worth every cent.', init: 'MR', colors: ['#9b5cff', '#ff9be0'] },
  { name: 'James Carter', role: 'Product Manager, Austin', quote: 'Best freelance developer I\'ve worked with — responsive, skilled, and genuinely invested in the outcome.', init: 'JC', colors: ['#6fa8ff', '#c89bff'] }
];
let dynamicTestimonials = [...fallbackTestimonials];

const tSlides = document.getElementById('t-slides');
const tDots = document.getElementById('t-dots');
let tIndex = 0;
let tAutoplay;

function renderTestimonials() {
  const tSlides = document.getElementById('t-slides');
  const tDots = document.getElementById('t-dots');
  if (!tSlides || !tDots) return;
  tSlides.innerHTML = '';
  tDots.innerHTML = '';
  dynamicTestimonials.forEach((t, i) => {
    tSlides.insertAdjacentHTML('beforeend', `
      <div class="t-slide"><div class="t-card">
        <div class="stars">${'★★★★★'.split('').map(() => '★').join('')}</div>
        <p class="quote">"${t.quote}"</p>
        <div class="t-person">
          <div class="t-avatar" style="background:linear-gradient(135deg,${t.colors[0]},${t.colors[1]})">${t.init}</div>
          <div><div class="pname">${t.name}</div><div class="prole">${t.role}</div></div>
        </div>
      </div></div>`);
    tDots.insertAdjacentHTML('beforeend', `<button data-i="${i}" class="${i === 0 ? 'active' : ''}"></button>`);
  });
  tIndex = 0;
  tSlides.style.transform = `translateX(0%)`;
}

function goSlide(i) {
  tIndex = (i + dynamicTestimonials.length) % dynamicTestimonials.length;
  tSlides.style.transform = `translateX(-${tIndex * 100}%)`;
  tDots.querySelectorAll('button').forEach((b, j) => b.classList.toggle('active', j === tIndex));
}
tDots.addEventListener('click', e => { const b = e.target.closest('button'); if (b) goSlide(+b.dataset.i); });
tAutoplay = setInterval(() => goSlide(tIndex + 1), 5500);
document.querySelector('.t-slider').addEventListener('mouseenter', () => clearInterval(tAutoplay));
document.querySelector('.t-slider').addEventListener('mouseleave', () => { tAutoplay = setInterval(() => goSlide(tIndex + 1), 5500); });

/* ======================================================
   FAQ & FALLBACKS
   ====================================================== */
const fallbackFaqs = [
  { q: 'How much does a project cost?', a: 'It depends on scope — a landing page starts around $1,000, while full platforms with AI or mobile apps typically range from $5,000–$30,000+. You\'ll get a clear quote after our free consultation call.' },
  { q: 'How long does a typical project take?', a: 'A website usually takes 1–3 weeks. Web or mobile applications typically take 4–10 weeks depending on complexity. You\'ll get a realistic timeline during planning, before any work begins.' },
  { q: 'Do I own the code and design after launch?', a: 'Yes — full ownership and source code are transferred to you once the project is paid in full. No vendor lock-in.' },
  { q: 'Can you take over an existing project?', a: 'Yes, I regularly audit and continue projects built by other developers or agencies, including messy or undocumented codebases.' },
  { q: 'What does ongoing support look like?', a: 'Every project includes a free support window after launch. After that, you can choose a monthly maintenance plan or pay as needed for updates.' },
  { q: 'How do we communicate during the project?', a: 'Email, Telegram or Slack — whichever you prefer — plus weekly progress updates and a shared project board so you always know where things stand.' },
  { q: 'What\'s the payment structure?', a: 'Typically a deposit to begin, a milestone payment partway through, and a final payment at launch. Larger projects can be split into more milestones.' }
];
let dynamicFaqs = [...fallbackFaqs];

const faqList = document.getElementById('faq-list');

function renderFAQs() {
  const faqList = document.getElementById('faq-list');
  if (!faqList) return;
  faqList.innerHTML = '';
  dynamicFaqs.forEach(f => {
    faqList.insertAdjacentHTML('beforeend', `
      <div class="faq-item">
        <button class="faq-q"><h4>${f.q}</h4><span class="plus"></span></button>
        <div class="faq-a"><p>${f.a}</p></div>
      </div>`);
  });

  // Add hover effect listener again to ring cursor
  faqList.querySelectorAll('.faq-q').forEach(el => {
    el.addEventListener('mouseenter', () => cring.classList.add('active'));
    el.addEventListener('mouseleave', () => cring.classList.remove('active'));
  });
}

/* ======================================================
   DYNAMIC API DATA FETCHING
   ====================================================== */
async function fetchDynamicData(lang) {
  try {
    const servicesRes = await fetch(`/api/services/?lang=${lang}`);
    if (servicesRes.ok) {
      const data = await servicesRes.json();
      if (data && data.length > 0) dynamicServices = data;
    }
  } catch (e) {
    console.error("Error fetching services:", e);
  }

  try {
    const stackRes = await fetch(`/api/portfolio/skills/?lang=${lang}`);
    if (stackRes.ok) {
      const data = await stackRes.json();
      if (data && data.length > 0) dynamicStack = data;
    }
  } catch (e) {
    console.error("Error fetching stack:", e);
  }

  try {
    const projectsRes = await fetch(`/api/portfolio/projects/?lang=${lang}`);
    if (projectsRes.ok) {
      const data = await projectsRes.json();
      if (data && data.length > 0) dynamicProjects = data;
    }
  } catch (e) {
    console.error("Error fetching projects:", e);
  }

  try {
    const testimonialsRes = await fetch(`/api/testimonials/?lang=${lang}`);
    if (testimonialsRes.ok) {
      const data = await testimonialsRes.json();
      if (data && data.length > 0) dynamicTestimonials = data;
    }
  } catch (e) {
    console.error("Error fetching testimonials:", e);
  }

  try {
    const faqsRes = await fetch(`/api/faq/?lang=${lang}`);
    if (faqsRes.ok) {
      const data = await faqsRes.json();
      if (data && data.length > 0) dynamicFaqs = data;
    }
  } catch (e) {
    console.error("Error fetching FAQs:", e);
  }

  // Render everything after loading
  renderServices();
  renderStack();
  const activeFilterBtn = document.querySelector('.filter-btn.active');
  const filterVal = activeFilterBtn ? activeFilterBtn.dataset.f : 'All';
  renderProjects(filterVal);
  renderTestimonials();
  renderFAQs();
}

// Initial trigger to load dynamic content on startup
document.addEventListener("DOMContentLoaded", () => {
  fetchDynamicData('en');
});
faqList.addEventListener('click', e => {
  const q = e.target.closest('.faq-q'); if (!q) return;
  const item = q.parentElement;
  const wasOpen = item.classList.contains('open');
  faqList.querySelectorAll('.faq-item').forEach(i => { i.classList.remove('open'); i.querySelector('.faq-a').style.maxHeight = null; });
  if (!wasOpen) { item.classList.add('open'); const a = item.querySelector('.faq-a'); a.style.maxHeight = a.scrollHeight + 'px'; }
});

/* ======================================================
   MINI CALENDAR (book a call)
   ====================================================== */
const miniCalEl = document.getElementById('mini-cal');
const dayLabels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
if (miniCalEl) {
  dayLabels.forEach(d => miniCalEl.insertAdjacentHTML('beforeend', `<span class="day-lbl">${d}</span>`));
  for (let i = 1; i <= 31; i++) {
    const isAvail = ![4, 5, 11, 12, 18, 19, 25, 26].includes(i);
    miniCalEl.insertAdjacentHTML('beforeend', `<span class="${isAvail ? 'avail' : ''} ${i === 8 ? 'sel' : ''}">${i}</span>`);
  }
  miniCalEl.addEventListener('click', e => {
    const s = e.target.closest('span.avail'); if (!s) return;
    miniCalEl.querySelectorAll('span.sel').forEach(x => x.classList.remove('sel'));
    s.classList.add('sel');
  });
}
const slotRowEl = document.querySelector('.slot-row');
if (slotRowEl) {
  slotRowEl.addEventListener('click', e => {
    const s = e.target.closest('.slot'); if (!s) return;
    document.querySelectorAll('.slot.sel').forEach(x => x.classList.remove('sel'));
    s.classList.add('sel');
  });
}

/* ======================================================
   CONTACT FORM (Django backend API integration)
   ====================================================== */
const uploadBox = document.querySelector('.upload-box');
if (uploadBox) {
  const fileInput = uploadBox.querySelector('input[type="file"]');
  uploadBox.addEventListener('click', (e) => {
    if (e.target !== fileInput) {
      fileInput.click();
    }
  });
  fileInput.addEventListener('change', () => {
    if (fileInput.files.length > 0) {
      uploadBox.querySelector('p').innerHTML = `Selected: <span>${fileInput.files[0].name}</span>`;
    } else {
      uploadBox.querySelector('p').innerHTML = `Drag a file here or <span>browse</span> — briefs, references, sketches`;
    }
  });
}

document.getElementById('contact-form').addEventListener('submit', async e => {
  e.preventDefault();

  const form = e.target;
  const submitButton = form.querySelector('button[type="submit"]');
  submitButton.disabled = true;
  submitButton.textContent = 'Sending...';

  const formData = new FormData();
  const csrfToken = form.querySelector('[name=csrfmiddlewaretoken]')?.value || '';
  if (csrfToken) formData.append('csrfmiddlewaretoken', csrfToken);
  formData.append('name', form.querySelector('input[placeholder="Your full name"]').value);
  formData.append('email', form.querySelector('input[placeholder="you@company.com"]').value);

  const phone = form.querySelector('input[placeholder="+998 ..."]').value;
  if (phone) formData.append('phone', phone);

  const company = form.querySelector('input[placeholder="Company name (optional)"]').value;
  if (company) formData.append('company', company);

  const budgetSelect = form.querySelector('select:nth-of-type(1)');
  if (budgetSelect && budgetSelect.value !== 'Select a range') {
    formData.append('budget', budgetSelect.value);
  }

  const projectTypeSelect = form.querySelector('select:nth-of-type(2)');
  if (projectTypeSelect && projectTypeSelect.value !== 'Select a type') {
    formData.append('project_type', projectTypeSelect.value);
  }

  const desc = form.querySelector('textarea[placeholder="What are you trying to build?"]').value;
  if (desc) formData.append('project_description', desc);

  const fileInput = form.querySelector('input[type="file"]');
  if (fileInput && fileInput.files.length > 0) {
    formData.append('attachment', fileInput.files[0]);
  }

  const message = form.querySelector('textarea[placeholder="Anything else I should know?"]').value;
  if (message) formData.append('message', message);

  try {
    const response = await fetch('/api/contacts/', {
      method: 'POST',
      body: formData
    });

    if (response.ok) {
      form.style.display = 'none';
      document.getElementById('form-success').classList.add('show');
    } else {
      const errData = await response.json();
      alert('Error submitting form: ' + JSON.stringify(errData));
      submitButton.disabled = false;
      submitButton.textContent = 'Send Project Request';
    }
  } catch (err) {
    alert('Error connecting to backend: ' + err.message);
    submitButton.disabled = false;
    submitButton.textContent = 'Send Project Request';
  }
});

/* ======================================================
   MINI CALENDAR & BOOKING FORM (Django backend API integration)
   ====================================================== */
let selectedDay = 8;
const miniCal2 = document.getElementById('mini-cal');
if (miniCal2) {
  miniCal2.addEventListener('click', e => {
    const s = e.target.closest('span.avail');
    if (!s) return;
    selectedDay = parseInt(s.textContent);
  });
}

let selectedSlot = "10:00";
const slotRow2 = document.querySelector('.slot-row');
if (slotRow2) {
  slotRow2.addEventListener('click', e => {
    const s = e.target.closest('.slot');

    if (!s) return;
    selectedSlot = s.textContent.trim();
  });
}

const bookingForm = document.getElementById('booking-form');
if (bookingForm) {
  bookingForm.addEventListener('submit', async e => {
    e.preventDefault();

    const submitButton = bookingForm.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    submitButton.textContent = 'Booking...';

    const payload = {
      name: document.getElementById('booking-name').value,
      email: document.getElementById('booking-email').value,
      phone: document.getElementById('booking-phone').value,
      date: `2026-07-${String(selectedDay).padStart(2, '0')}`,
      time_slot: selectedSlot
    };

    const csrfToken = bookingForm.querySelector('[name=csrfmiddlewaretoken]')?.value || '';
    const headers = {
      'Content-Type': 'application/json'
    };
    if (csrfToken) {
      headers['X-CSRFToken'] = csrfToken;
    }

    try {
      const response = await fetch('/api/bookings/', {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        bookingForm.style.display = 'none';
        document.getElementById('booking-success').style.display = 'block';
      } else {
        const errData = await response.json();
        alert('Booking error: ' + JSON.stringify(errData));
        submitButton.disabled = false;
        submitButton.textContent = 'Confirm Booking';
      }
    } catch (err) {
      alert('Error connecting to backend: ' + err.message);
      submitButton.disabled = false;
      submitButton.textContent = 'Confirm Booking';
    }
  });
}

/* ======================================================
   CHAT WIDGET
   ====================================================== */
const chatPanel = document.getElementById('chat-panel');
const chatBody = document.getElementById('chat-body');
document.getElementById('chat-toggle').addEventListener('click', () => chatPanel.classList.toggle('open'));
// ══════════════════════════════════════════════════
// ⚡ GEMINI 2.5 FLASH — вставьте ваш API ключ
// Получить бесплатно: https://aistudio.google.com/
// ══════════════════════════════════════════════════
const GEMINI_API_KEY = 'AQ.Ab8RN6K3UCl-KvF72DtZhlm3LKG1Jv82DQ54JOGVdumEN5agmA';
const GEMINI_MODEL = 'gemini-2.5-flash';
const GEMINI_SYSTEM = `Ты — AI-ассистент портфолио-сайта Ulugbek Khasanov (khasanov.dev).
Ulugbek — Full Stack Developer и AI Engineer из Ташкента. Работает удалённо по всему миру.
Услуги: сайты ($500–$3000), веб-приложения ($3000–$20000), мобильные приложения ($5000–$15000), Telegram боты (от $500), AI-системы ($2000–$8000), автоматизация.
Стек: React, Next.js, Python, Django, FastAPI, Flutter, PostgreSQL, Docker, AWS, OpenAI, Gemini, Claude.
Контакты: WhatsApp +998 50 153 65 19, Telegram @Khasanov_000, Email xasanovulugbek574@gmail.com.
Бесплатная консультация: 30 минут без обязательств.
Отвечай на языке пользователя (русский, узбекский, английский). Ответы короткие и конкретные.`;
const chatHistory = [];
const fallbackAnswers = {
  pricing: '💰 Ориентировочные цены:\n• Лендинг: от $500\n• Сайт: $1000–$3000\n• Веб-приложение: $3000–$20000\n• Мобильное приложение: $5000–$15000\n• Telegram бот: от $500\n\nТочную цену рассчитаю на бесплатном звонке!',
  timeline: '⏱️ Сроки:\n• Лендинг: 1–2 нед.\n• Сайт: 2–3 нед.\n• Веб-приложение: 4–10 нед.\n• Мобильное приложение: 6–12 нед.',
  stack: '🛠️ Стек:\n• Frontend: React, Next.js, TypeScript\n• Backend: Python, Django, FastAPI\n• Mobile: Flutter\n• AI: OpenAI, Gemini 2.5, Claude\n• Cloud: Docker, AWS, GCP',
  contact: '📞 Связаться:\n• WhatsApp: +998 50 153 65 19\n• Telegram: @Khasanov_000\n• Email: xasanovulugbek574@gmail.com'
};
async function askGemini(msg) {
  if (!GEMINI_API_KEY) return null;
  chatHistory.push({ role: 'user', parts: [{ text: msg }] });
  try {
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ system_instruction: { parts: [{ text: GEMINI_SYSTEM }] }, contents: chatHistory, generationConfig: { maxOutputTokens: 280, temperature: 0.75 } })
    });
    const d = await r.json();
    if (d.error) { chatHistory.pop(); return null; }
    const reply = d.candidates?.[0]?.content?.parts?.[0]?.text || null;
    if (reply) chatHistory.push({ role: 'model', parts: [{ text: reply }] });
    return reply;
  } catch (e) { chatHistory.pop(); return null; }
}
function addBubble(type, text) {
  const b = document.createElement('div'); b.className = `bubble ${type}`;
  b.style.cssText = 'max-width:86%;padding:10px 14px;border-radius:14px;font-size:.83rem;line-height:1.55;white-space:pre-line;';
  if (type === 'bot') b.style.cssText += 'background:rgba(255,255,255,.08);align-self:flex-start;border-bottom-left-radius:4px;';
  else b.style.cssText += 'background:linear-gradient(135deg,#3a7cff,#6c3df0);align-self:flex-end;border-bottom-right-radius:4px;';
  b.textContent = text;
  chatBody.appendChild(b); chatBody.scrollTop = 99999;
}
function showTyping() {
  const t = document.createElement('div'); t.id = 'typdot'; t.className = 'bubble bot';
  t.style.cssText = 'max-width:60px;padding:12px 16px;border-radius:14px;display:flex;gap:5px;align-items:center;align-self:flex-start;background:rgba(255,255,255,.08);';
  t.innerHTML = '<span style="width:6px;height:6px;border-radius:50%;background:#5c5f74;animation:blk 1.1s ease infinite"></span><span style="width:6px;height:6px;border-radius:50%;background:#5c5f74;animation:blk 1.1s ease .2s infinite"></span><span style="width:6px;height:6px;border-radius:50%;background:#5c5f74;animation:blk 1.1s ease .4s infinite"></span>';
  chatBody.appendChild(t); chatBody.scrollTop = 99999;
}
function hideTyping() { const t = document.getElementById('typdot'); if (t) t.remove(); }
async function handleChat(msg) {
  if (!msg.trim()) return;
  addBubble('user', msg);
  const qinput = document.querySelector('.chat-panel input');
  if (qinput) qinput.value = '';
  showTyping();
  let reply = null;
  if (GEMINI_API_KEY) {
    reply = await askGemini(msg);
  } else {
    await new Promise(r => setTimeout(r, 650));
    const lc = msg.toLowerCase();
    if (lc.includes('цен') || lc.includes('стоит') || lc.includes('бюджет') || lc.includes('price') || lc.includes('cost')) reply = fallbackAnswers.pricing;
    else if (lc.includes('срок') || lc.includes('времен') || lc.includes('быстро') || lc.includes('time')) reply = fallbackAnswers.timeline;
    else if (lc.includes('стек') || lc.includes('технолог') || lc.includes('stack')) reply = fallbackAnswers.stack;
    else if (lc.includes('связ') || lc.includes('contact') || lc.includes('telegram') || lc.includes('whatsapp') || lc.includes('звонок')) reply = fallbackAnswers.contact;
    else reply = 'Спасибо за вопрос! Для точного ответа напишите Улугбеку:\n📱 WA: +998 50 153 65 19\n📩 TG: @Khasanov_000';
  }
  hideTyping();
  if (reply) { addBubble('bot', reply); }
  else { addBubble('bot', '⚠️ Ошибка AI. Напишите напрямую:\n📱 WA: +998 50 153 65 19\n📩 TG: @Khasanov_000'); }
}
document.getElementById('chat-quick').addEventListener('click', e => {
  const btn = e.target.closest('.qbtn'); if (!btn) return;
  const qmap = { pricing: 'Цены на проекты', timeline: 'Сроки разработки', stack: 'Технологический стек', contact: 'Как связаться' };
  handleChat(qmap[btn.dataset.q] || btn.textContent);
});

