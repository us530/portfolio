import requests
import json

base_url = "http://127.0.0.1:8000"

print("--- Testing Contacts API ---")
contact_payload = {
    "name": "Test User",
    "email": "test@example.com",
    "phone": "+998901234567",
    "company": "Test Company",
    "budget": "$3,000 – $10,000",
    "project_type": "Web Application",
    "project_description": "We need a custom dashboard",
    "message": "Hello from backend test!"
}

try:
    response = requests.post(f"{base_url}/api/contacts/", data=contact_payload)
    print("Contacts Status Code:", response.status_code)
    print("Contacts Response:", response.json())
except Exception as e:
    print("Contacts API Error:", e)

print("\n--- Testing Bookings API ---")
booking_payload = {
    "name": "Test Booking User",
    "email": "testbooking@example.com",
    "phone": "+998907654321",
    "date": "2026-07-28",
    "time_slot": "13:30"
}

try:
    response = requests.post(
        f"{base_url}/api/bookings/",
        headers={"Content-Type": "application/json"},
        data=json.dumps(booking_payload)
    )
    print("Bookings Status Code:", response.status_code)
    print("Bookings Response:", response.json())
except Exception as e:
    print("Bookings API Error:", e)
