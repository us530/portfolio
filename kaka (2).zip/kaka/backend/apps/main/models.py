from django.db import models

class SingletonModel(models.Model):
    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        self.pk = 1
        super().save(*args, **kwargs)

    @classmethod
    def load(cls):
        obj, created = cls.objects.get_or_create(pk=1)
        return obj


class HeroSection(SingletonModel):
    name_en = models.CharField(max_length=150, default="Ulugbek Xasanov")
    name_ru = models.CharField(max_length=150, blank=True)
    name_uz = models.CharField(max_length=150, blank=True)
    
    profession_en = models.CharField(max_length=200, default="Full Stack Developer")
    profession_ru = models.CharField(max_length=200, blank=True)
    profession_uz = models.CharField(max_length=200, blank=True)
    
    description_en = models.TextField(default="I build modern websites, powerful web applications, AI systems, Telegram bots...")
    description_ru = models.TextField(blank=True)
    description_uz = models.TextField(blank=True)
    
    photo = models.ImageField(upload_to='hero/', blank=True, null=True)
    
    github_url = models.URLField(blank=True, null=True)
    linkedin_url = models.URLField(blank=True, null=True)
    telegram_url = models.URLField(blank=True, null=True)
    instagram_url = models.URLField(blank=True, null=True)

    class Meta:
        verbose_name = "Hero Section"
        verbose_name_plural = "Hero Section"

    def __str__(self):
        return f"Hero Section ({self.name_en})"


class About(SingletonModel):
    title_en = models.CharField(max_length=250, default="Engineering products, not just code")
    title_ru = models.CharField(max_length=250, blank=True)
    title_uz = models.CharField(max_length=250, blank=True)
    
    bio_en = models.TextField()
    bio_ru = models.TextField(blank=True)
    bio_uz = models.TextField(blank=True)
    
    photo = models.ImageField(upload_to='about/', blank=True, null=True)
    cv = models.FileField(upload_to='cv/', blank=True, null=True)
    
    age = models.PositiveIntegerField(blank=True, null=True)
    experience_years = models.PositiveIntegerField(default=7)
    
    location_en = models.CharField(max_length=200, default="Tashkent, Uzbekistan")
    location_ru = models.CharField(max_length=200, blank=True)
    location_uz = models.CharField(max_length=200, blank=True)

    class Meta:
        verbose_name = "About Me"
        verbose_name_plural = "About Me"

    def __str__(self):
        return "About Me Configuration"


class ContactInfo(SingletonModel):
    email = models.EmailField(default="xasanovulugbek574@gmail.com")
    phone = models.CharField(max_length=50, default="+998 50 153 65 19")
    telegram = models.CharField(max_length=100, default="@Khasanov_000")
    github = models.URLField(blank=True, null=True)
    linkedin = models.URLField(blank=True, null=True)
    instagram = models.URLField(blank=True, null=True)
    
    address_en = models.CharField(max_length=250, blank=True)
    address_ru = models.CharField(max_length=250, blank=True)
    address_uz = models.CharField(max_length=250, blank=True)

    class Meta:
        verbose_name = "Contact Info"
        verbose_name_plural = "Contact Info"

    def __str__(self):
        return f"Contact Info ({self.email})"


class SiteSettings(SingletonModel):
    site_name = models.CharField(max_length=150, default="Khasanov.dev")
    logo = models.ImageField(upload_to='settings/', blank=True, null=True)
    favicon = models.ImageField(upload_to='settings/', blank=True, null=True)
    
    footer_text_en = models.TextField(blank=True)
    footer_text_ru = models.TextField(blank=True)
    footer_text_uz = models.TextField(blank=True)
    
    copyright_text_en = models.CharField(max_length=250, blank=True)
    copyright_text_ru = models.CharField(max_length=250, blank=True)
    copyright_text_uz = models.CharField(max_length=250, blank=True)
    
    seo_title_en = models.CharField(max_length=200, blank=True)
    seo_title_ru = models.CharField(max_length=200, blank=True)
    seo_title_uz = models.CharField(max_length=200, blank=True)
    
    seo_description_en = models.TextField(blank=True)
    seo_description_ru = models.TextField(blank=True)
    seo_description_uz = models.TextField(blank=True)
    
    google_analytics_id = models.CharField(max_length=100, blank=True)
    custom_meta_tags = models.TextField(blank=True, help_text="Raw HTML scripts/meta tags (e.g. for Google Search Console, widgets)")

    class Meta:
        verbose_name = "Site Settings"
        verbose_name_plural = "Site Settings"

    def __str__(self):
        return self.site_name
