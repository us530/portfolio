from django.contrib import admin
from django.utils.safestring import mark_safe
from unfold.admin import ModelAdmin
from .models import HeroSection, About, ContactInfo, SiteSettings

class SingletonModelAdmin(ModelAdmin):
    # Prevent adding more than one record
    def has_add_permission(self, request):
        return not self.model.objects.exists()

    # Prevent deleting the configuration
    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(HeroSection)
class HeroSectionAdmin(SingletonModelAdmin):
    list_display = ('name_en', 'profession_en', 'photo_preview')
    readonly_fields = ('photo_preview',)

    fieldsets = (
        ('Basic Information (English)', {
            'fields': ('name_en', 'profession_en', 'description_en')
        }),
        ('Translations (Russian)', {
            'fields': ('name_ru', 'profession_ru', 'description_ru')
        }),
        ('Translations (Uzbek)', {
            'fields': ('name_uz', 'profession_uz', 'description_uz')
        }),
        ('Assets & Styling', {
            'fields': ('photo', 'photo_preview')
        }),
        ('Social Links', {
            'fields': ('github_url', 'linkedin_url', 'telegram_url', 'instagram_url')
        }),
    )

    def photo_preview(self, obj):
        if obj.photo:
            return mark_safe(f'<img src="{obj.photo.url}" style="max-height: 150px; border-radius: 8px;" />')
        return "No image uploaded"
    photo_preview.short_description = "Photo Preview"


@admin.register(About)
class AboutAdmin(SingletonModelAdmin):
    list_display = ('title_en', 'age', 'experience_years', 'location_en', 'photo_preview')
    readonly_fields = ('photo_preview',)

    fieldsets = (
        ('Biography (English)', {
            'fields': ('title_en', 'bio_en')
        }),
        ('Translations (Russian)', {
            'fields': ('title_ru', 'bio_ru')
        }),
        ('Translations (Uzbek)', {
            'fields': ('title_uz', 'bio_uz')
        }),
        ('Details', {
            'fields': ('age', 'experience_years', 'location_en', 'location_ru', 'location_uz')
        }),
        ('Files', {
            'fields': ('photo', 'photo_preview', 'cv')
        }),
    )

    def photo_preview(self, obj):
        if obj.photo:
            return mark_safe(f'<img src="{obj.photo.url}" style="max-height: 150px; border-radius: 8px;" />')
        return "No image uploaded"
    photo_preview.short_description = "Photo Preview"


@admin.register(ContactInfo)
class ContactInfoAdmin(SingletonModelAdmin):
    list_display = ('email', 'phone', 'telegram')

    fieldsets = (
        ('Contact Channels', {
            'fields': ('email', 'phone', 'telegram')
        }),
        ('Social Profiles', {
            'fields': ('github', 'linkedin', 'instagram')
        }),
        ('Location Address', {
            'fields': ('address_en', 'address_ru', 'address_uz')
        }),
    )


@admin.register(SiteSettings)
class SiteSettingsAdmin(SingletonModelAdmin):
    list_display = ('site_name', 'logo_preview', 'favicon_preview')
    readonly_fields = ('logo_preview', 'favicon_preview')

    fieldsets = (
        ('General Config', {
            'fields': ('site_name', 'logo', 'logo_preview', 'favicon', 'favicon_preview')
        }),
        ('Footer & Copyright (English)', {
            'fields': ('footer_text_en', 'copyright_text_en')
        }),
        ('Translations (Russian)', {
            'fields': ('footer_text_ru', 'copyright_text_ru')
        }),
        ('Translations (Uzbek)', {
            'fields': ('footer_text_uz', 'copyright_text_uz')
        }),
        ('SEO Meta (English)', {
            'fields': ('seo_title_en', 'seo_description_en')
        }),
        ('SEO Translations (Russian)', {
            'fields': ('seo_title_ru', 'seo_description_ru')
        }),
        ('SEO Translations (Uzbek)', {
            'fields': ('seo_title_uz', 'seo_description_uz')
        }),
        ('Analytics & Scripts', {
            'fields': ('google_analytics_id', 'custom_meta_tags'),
            'description': 'Add Google Analytics and custom site tags/scipts here.'
        }),
    )

    def logo_preview(self, obj):
        if obj.logo:
            return mark_safe(f'<img src="{obj.logo.url}" style="max-height: 50px;" />')
        return "No logo uploaded"
    logo_preview.short_description = "Logo Preview"

    def favicon_preview(self, obj):
        if obj.favicon:
            return mark_safe(f'<img src="{obj.favicon.url}" style="max-height: 32px;" />')
        return "No favicon uploaded"
    favicon_preview.short_description = "Favicon Preview"
