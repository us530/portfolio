from django.urls import include, path
from rest_framework.routers import DefaultRouter

from bookings.views import BookingViewSet
from contacts.views import ContactRequestViewSet
from custom_orders.views import CustomOrderViewSet
from faq.views import FAQViewSet
from portfolio.views import ProjectViewSet, SkillCategoryViewSet
from quotations.views import QuotationRequestViewSet
from services.views import ServiceViewSet
from testimonials.views import TestimonialViewSet

router = DefaultRouter()
router.register(r'contacts', ContactRequestViewSet, basename='contact')
router.register(r'bookings', BookingViewSet, basename='booking')
router.register(r'quotations', QuotationRequestViewSet, basename='quotation')
router.register(r'custom-orders', CustomOrderViewSet, basename='custom-order')
router.register(r'portfolio/skills', SkillCategoryViewSet, basename='skill-category')
router.register(r'portfolio/projects', ProjectViewSet, basename='project')
router.register(r'services', ServiceViewSet, basename='service')
router.register(r'testimonials', TestimonialViewSet, basename='testimonial')
router.register(r'faq', FAQViewSet, basename='faq')

urlpatterns = [
    path('', include(router.urls)),
]
