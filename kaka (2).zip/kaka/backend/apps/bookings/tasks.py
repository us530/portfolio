import logging

from celery import shared_task
from django.core.mail import send_mail
from django.conf import settings

from core.telegram import escape_html, send_telegram_message
from .models import Booking

logger = logging.getLogger(__name__)


def format_booking_telegram_message(booking):
    return (
        '📅 <b>New Consultation Booking!</b>\n\n'
        f'👤 <b>Name:</b> {escape_html(booking.name)}\n'
        f'📧 <b>Email:</b> {escape_html(booking.email)}\n'
        f'📞 <b>Phone:</b> {escape_html(booking.phone)}\n'
        f'🗓️ <b>Date:</b> {escape_html(booking.date)}\n'
        f'⏰ <b>Time:</b> {escape_html(booking.time_slot)}\n'
        f'🕐 <b>Booked at:</b> {escape_html(booking.created_at)}'
    )


@shared_task
def send_booking_notifications(booking_id):
    try:
        booking = Booking.objects.get(id=booking_id)
    except Booking.DoesNotExist:
        logger.error('Booking with ID %s does not exist.', booking_id)
        return

    email_subject = f'New Consultation Booking from {booking.name}'
    email_body = f"""
You received a new consultation booking on Khasanov.dev:

Name: {booking.name}
Email: {booking.email}
Phone: {booking.phone}
Date: {booking.date}
Time: {booking.time_slot}
Created At: {booking.created_at}
"""
    try:
        send_mail(
            subject=email_subject,
            message=email_body,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[getattr(settings, 'EMAIL_HOST_USER', '')],
            fail_silently=True,
        )
        logger.info('Booking notification email sent successfully.')
    except Exception as exc:
        logger.error('Failed to send booking notification email: %s', exc)

    send_telegram_message(format_booking_telegram_message(booking))
