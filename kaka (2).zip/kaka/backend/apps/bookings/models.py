from django.db import models
from django.conf import settings

class Booking(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='bookings')
    name = models.CharField(max_length=150)
    email = models.EmailField()
    phone = models.CharField(max_length=50)
    date = models.DateField()
    time_slot = models.CharField(max_length=10) # e.g. "10:00", "13:30"
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date', 'time_slot']
        unique_together = ('date', 'time_slot') # Prevent double booking of same slot

    def __str__(self):
        return f"{self.name} - {self.date} at {self.time_slot}"
