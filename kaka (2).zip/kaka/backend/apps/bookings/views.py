from datetime import datetime

from rest_framework import permissions, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import Booking
from .serializers import BookingSerializer
from .tasks import send_booking_notifications

class BookingViewSet(viewsets.ModelViewSet):
    queryset = Booking.objects.all()
    serializer_class = BookingSerializer
    
    def get_permissions(self):
        if self.action in ['create', 'available_slots']:
            return [permissions.AllowAny()]
        return [permissions.IsAdminUser()]

    def perform_create(self, serializer):
        if self.request.user.is_authenticated:
            instance = serializer.save(user=self.request.user)
        else:
            instance = serializer.save()
        send_booking_notifications.delay(instance.id)

    @action(detail=False, methods=['get'])
    def available_slots(self, request):
        date_str = request.query_params.get('date')
        if not date_str:
            return Response({'error': 'Date parameter (YYYY-MM-DD) is required'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            target_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        except ValueError:
            return Response({'error': 'Invalid date format. Use YYYY-MM-DD'}, status=status.HTTP_400_BAD_REQUEST)

        # Standard time slots
        all_slots = ["10:00", "13:30", "16:00", "18:30"]
        
        # Query booked slots
        booked_slots = Booking.objects.filter(date=target_date).values_list('time_slot', flat=True)
        
        # Filter out booked slots
        available = [slot for slot in all_slots if slot not in booked_slots]
        
        return Response({
            'date': date_str,
            'available_slots': available,
            'booked_slots': list(booked_slots)
        })
