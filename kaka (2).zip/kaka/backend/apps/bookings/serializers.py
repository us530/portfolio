from rest_framework import serializers
from .models import Booking
from datetime import date

class BookingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Booking
        fields = ('id', 'name', 'email', 'phone', 'date', 'time_slot', 'created_at')
        read_only_fields = ('id', 'created_at')

    def validate_date(self, value):
        if value < date.today():
            raise serializers.ValidationError("Cannot book a date in the past.")
        return value

    def validate(self, data):
        # Double check availability (should trigger unique_together, but explicit validation is cleaner)
        booking_date = data.get('date')
        time_slot = data.get('time_slot')
        
        if Booking.objects.filter(date=booking_date, time_slot=time_slot).exists():
            raise serializers.ValidationError("This time slot is already booked.")
            
        return data
