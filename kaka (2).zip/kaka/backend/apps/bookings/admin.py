from django.contrib import admin
from unfold.admin import ModelAdmin
from .models import Booking

@admin.register(Booking)
class BookingAdmin(ModelAdmin):
    list_display = ('name', 'email', 'phone', 'date', 'time_slot', 'created_at')
    list_filter = ('date', 'time_slot')
    search_fields = ('name', 'email', 'phone')
    ordering = ('-date', 'time_slot')
