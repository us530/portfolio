from django.db import models


class CustomOrder(models.Model):
    name = models.CharField(max_length=150)
    email = models.EmailField()
    phone = models.CharField(max_length=50, blank=True, null=True)
    product_name = models.CharField(max_length=200)
    specifications = models.TextField(blank=True, null=True)
    quantity = models.PositiveIntegerField(blank=True, null=True)
    budget = models.CharField(max_length=100, blank=True, null=True)
    attachment = models.FileField(upload_to='custom_order_attachments/', blank=True, null=True)
    message = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'Custom order from {self.name} ({self.product_name})'
