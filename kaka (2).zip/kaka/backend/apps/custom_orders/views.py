from rest_framework import permissions, viewsets

from .models import CustomOrder
from .serializers import CustomOrderSerializer
from .tasks import send_custom_order_notifications


class CustomOrderViewSet(viewsets.ModelViewSet):
    queryset = CustomOrder.objects.all()
    serializer_class = CustomOrderSerializer

    def get_permissions(self):
        if self.action == 'create':
            return [permissions.AllowAny()]
        return [permissions.IsAdminUser()]

    def perform_create(self, serializer):
        instance = serializer.save()
        send_custom_order_notifications.delay(instance.id)
