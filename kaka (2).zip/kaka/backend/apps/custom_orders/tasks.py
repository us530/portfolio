import logging

from celery import shared_task
from django.conf import settings
from django.core.mail import send_mail

from core.telegram import escape_html, send_telegram_message
from .models import CustomOrder

logger = logging.getLogger(__name__)


def format_custom_order_telegram_message(order):
    attachment = order.attachment.url if order.attachment else 'None'
    return (
        '🛒 <b>New Custom Order!</b>\n\n'
        f'👤 <b>Name:</b> {escape_html(order.name)}\n'
        f'📧 <b>Email:</b> {escape_html(order.email)}\n'
        f'📞 <b>Phone:</b> {escape_html(order.phone)}\n'
        f'📦 <b>Product:</b> {escape_html(order.product_name)}\n'
        f'🔢 <b>Quantity:</b> {escape_html(order.quantity)}\n'
        f'💰 <b>Budget:</b> {escape_html(order.budget)}\n\n'
        f'📋 <b>Specifications:</b>\n{escape_html(order.specifications)}\n\n'
        f'💬 <b>Message:</b>\n{escape_html(order.message)}\n\n'
        f'📎 <b>Attachment:</b> {escape_html(attachment)}'
    )


@shared_task
def send_custom_order_notifications(order_id):
    try:
        order = CustomOrder.objects.get(id=order_id)
    except CustomOrder.DoesNotExist:
        logger.error('CustomOrder with ID %s does not exist.', order_id)
        return

    email_subject = f'New Custom Order from {order.name}'
    email_body = f"""
You received a new custom order on Khasanov.dev:

Name: {order.name}
Email: {order.email}
Phone: {order.phone or 'N/A'}
Product: {order.product_name}
Quantity: {order.quantity or 'N/A'}
Budget: {order.budget or 'N/A'}

Specifications:
{order.specifications or 'No specifications provided.'}

Message:
{order.message or 'No message provided.'}

Attachment: {order.attachment.url if order.attachment else 'No attachment uploaded'}
Created At: {order.created_at}
"""
    try:
        send_mail(
            subject=email_subject,
            message=email_body,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[getattr(settings, 'EMAIL_HOST_USER', '')],
            fail_silently=True,
        )
        logger.info('Custom order notification email sent successfully.')
    except Exception as exc:
        logger.error('Failed to send custom order notification email: %s', exc)

    send_telegram_message(format_custom_order_telegram_message(order))
