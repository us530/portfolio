from django.contrib import admin
from unfold.admin import ModelAdmin

from .models import CustomOrder


@admin.register(CustomOrder)
class CustomOrderAdmin(ModelAdmin):
    list_display = ('name', 'email', 'product_name', 'quantity', 'budget', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('name', 'email', 'product_name', 'specifications', 'message')
    readonly_fields = ('created_at',)
    ordering = ('-created_at',)
