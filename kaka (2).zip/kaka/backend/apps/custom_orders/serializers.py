from rest_framework import serializers

from .models import CustomOrder


class CustomOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomOrder
        fields = (
            'id', 'name', 'email', 'phone', 'product_name', 'specifications',
            'quantity', 'budget', 'attachment', 'message', 'created_at',
        )
        read_only_fields = ('id', 'created_at')
