from django.db import models
from django.utils.text import slugify

class SkillCategory(models.Model):
    name_en = models.CharField(max_length=100)
    name_ru = models.CharField(max_length=100, blank=True)
    name_uz = models.CharField(max_length=100, blank=True)
    color = models.CharField(max_length=30, default='#6fa8ff', help_text="Hex color string, e.g., #6fa8ff")

    class Meta:
        verbose_name = "Skill Category"
        verbose_name_plural = "Skill Categories"

    def __str__(self):
        return self.name_en


class Skill(models.Model):
    category = models.ForeignKey(SkillCategory, related_name='skills', on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    level = models.PositiveIntegerField(default=100, help_text="Percentage level of proficiency (0-100)")
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['order', 'name']

    def __str__(self):
        return f"{self.category.name_en} - {self.name} ({self.level}%)"


class Project(models.Model):
    CATEGORY_CHOICES = [
        ('Website', 'Website'),
        ('Web App', 'Web App'),
        ('Mobile App', 'Mobile App'),
        ('AI / Automation', 'AI / Automation'),
    ]
    STATUS_CHOICES = [
        ('Draft', 'Draft'),
        ('Published', 'Published'),
        ('Featured', 'Featured'),
    ]
    
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES)
    name = models.CharField(max_length=200)
    slug = models.SlugField(max_length=250, unique=True, blank=True)
    image = models.ImageField(upload_to='projects/', blank=True, null=True)
    image_url = models.URLField(max_length=500, blank=True, null=True, help_text="Fallback external URL if no image uploaded")
    
    # Gradients colors, e.g. ["#3b7cff", "#6c3df0"]
    colors = models.JSONField(default=list, help_text="List of two hex colors for card gradient, e.g. ['#3b7cff', '#6c3df0']")
    
    # Technology list, e.g. ["Next.js", "Django", "PostgreSQL", "OpenAI"]
    tech = models.JSONField(default=list, help_text="List of technology names")
    
    # Multilingual Descriptions (Short)
    desc_en = models.TextField(help_text="Short description in English")
    desc_ru = models.TextField(blank=True, help_text="Short description in Russian")
    desc_uz = models.TextField(blank=True, help_text="Short description in Uzbek")
    
    # Multilingual Full Descriptions
    full_description_en = models.TextField(blank=True, help_text="Full description in English")
    full_description_ru = models.TextField(blank=True, help_text="Full description in Russian")
    full_description_uz = models.TextField(blank=True, help_text="Full description in Uzbek")
    
    # Multilingual Features
    features_en = models.JSONField(default=list, help_text="List of features in English")
    features_ru = models.JSONField(default=list, blank=True, help_text="List of features in Russian")
    features_uz = models.JSONField(default=list, blank=True, help_text="List of features in Uzbek")
    
    # Multilingual Quote
    quote_en = models.TextField(blank=True)
    quote_ru = models.TextField(blank=True)
    quote_uz = models.TextField(blank=True)
    
    # Multilingual Client
    client_en = models.CharField(max_length=200, blank=True)
    client_ru = models.CharField(max_length=200, blank=True)
    client_uz = models.CharField(max_length=200, blank=True)
    
    live_demo_url = models.URLField(blank=True, null=True)
    github_url = models.URLField(blank=True, null=True)
    
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Published')
    published_date = models.DateField(blank=True, null=True)
    
    seo_title = models.CharField(max_length=255, blank=True, help_text="SEO Title tag")
    seo_description = models.TextField(blank=True, help_text="SEO Meta Description")
    
    order = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['order', '-created_at']

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class ProjectImage(models.Model):
    project = models.ForeignKey(Project, related_name='gallery', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='projects/gallery/')
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['order', 'id']
        verbose_name = "Project Gallery Image"
        verbose_name_plural = "Project Gallery Images"

    def __str__(self):
        return f"Gallery image for {self.project.name}"


class Certificate(models.Model):
    title = models.CharField(max_length=200)
    organization = models.CharField(max_length=200)
    date = models.DateField()
    image = models.ImageField(upload_to='certificates/', blank=True, null=True)
    pdf = models.FileField(upload_to='certificates/pdf/', blank=True, null=True)

    class Meta:
        ordering = ['-date', 'title']

    def __str__(self):
        return f"{self.title} - {self.organization}"


class Experience(models.Model):
    company = models.CharField(max_length=200)
    
    position_en = models.CharField(max_length=200)
    position_ru = models.CharField(max_length=200, blank=True)
    position_uz = models.CharField(max_length=200, blank=True)
    
    period_en = models.CharField(max_length=100, help_text="e.g. 2021 - Present")
    period_ru = models.CharField(max_length=100, blank=True)
    period_uz = models.CharField(max_length=100, blank=True)
    
    description_en = models.TextField()
    description_ru = models.TextField(blank=True)
    description_uz = models.TextField(blank=True)
    
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['order', '-id']

    def __str__(self):
        return f"{self.position_en} at {self.company}"


class Education(models.Model):
    institution_en = models.CharField(max_length=200)
    institution_ru = models.CharField(max_length=200, blank=True)
    institution_uz = models.CharField(max_length=200, blank=True)
    
    specialty_en = models.CharField(max_length=200)
    specialty_ru = models.CharField(max_length=200, blank=True)
    specialty_uz = models.CharField(max_length=200, blank=True)
    
    years_en = models.CharField(max_length=100, help_text="e.g. 2017 - 2021")
    years_ru = models.CharField(max_length=100, blank=True)
    years_uz = models.CharField(max_length=100, blank=True)
    
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['order', '-id']
        verbose_name = "Education Record"
        verbose_name_plural = "Education Records"

    def __str__(self):
        return f"{self.specialty_en} - {self.institution_en}"
