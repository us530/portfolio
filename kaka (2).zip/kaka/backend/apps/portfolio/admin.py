from django.contrib import admin
from django.utils.safestring import mark_safe
from unfold.admin import ModelAdmin, TabularInline
from .models import SkillCategory, Skill, Project, ProjectImage, Certificate, Experience, Education

class SkillInline(TabularInline):
    model = Skill
    extra = 1
    fields = ('name', 'level', 'order')


@admin.register(SkillCategory)
class SkillCategoryAdmin(ModelAdmin):
    list_display = ('name_en', 'name_ru', 'name_uz', 'color')
    search_fields = ('name_en', 'name_ru', 'name_uz')
    inlines = [SkillInline]


class ProjectImageInline(TabularInline):
    model = ProjectImage
    extra = 3
    fields = ('image', 'order')


@admin.register(Project)
class ProjectAdmin(ModelAdmin):
    list_display = ('name', 'category', 'status', 'published_date', 'order', 'image_preview')
    list_filter = ('category', 'status', 'published_date')
    search_fields = ('name', 'desc_en', 'desc_ru', 'desc_uz', 'seo_title')
    prepopulated_fields = {'slug': ('name',)}
    readonly_fields = ('image_preview',)
    inlines = [ProjectImageInline]

    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'slug', 'category', 'status', 'published_date', 'order')
        }),
        ('Media Assets', {
            'fields': ('image', 'image_preview', 'image_url', 'colors')
        }),
        ('Technologies', {
            'fields': ('tech',)
        }),
        ('Descriptions (English)', {
            'fields': ('desc_en', 'full_description_en')
        }),
        ('Descriptions (Russian)', {
            'fields': ('desc_ru', 'full_description_ru')
        }),
        ('Descriptions (Uzbek)', {
            'fields': ('desc_uz', 'full_description_uz')
        }),
        ('Project Extra Info', {
            'fields': ('features_en', 'features_ru', 'features_uz', 'client_en', 'client_ru', 'client_uz', 'quote_en', 'quote_ru', 'quote_uz')
        }),
        ('Links', {
            'fields': ('live_demo_url', 'github_url')
        }),
        ('SEO Metadata', {
            'fields': ('seo_title', 'seo_description')
        }),
    )

    def image_preview(self, obj):
        if obj.image:
            return mark_safe(f'<img src="{obj.image.url}" style="max-height: 50px; border-radius: 4px;" />')
        elif obj.image_url:
            return mark_safe(f'<img src="{obj.image_url}" style="max-height: 50px; border-radius: 4px;" />')
        return "No image"
    image_preview.short_description = "Image Preview"


@admin.register(Certificate)
class CertificateAdmin(ModelAdmin):
    list_display = ('title', 'organization', 'date', 'image_preview')
    list_filter = ('organization', 'date')
    search_fields = ('title', 'organization')
    readonly_fields = ('image_preview',)

    def image_preview(self, obj):
        if obj.image:
            return mark_safe(f'<img src="{obj.image.url}" style="max-height: 50px; border-radius: 4px;" />')
        return "No image"
    image_preview.short_description = "Image Preview"


@admin.register(Experience)
class ExperienceAdmin(ModelAdmin):
    list_display = ('company', 'position_en', 'period_en', 'order')
    list_filter = ('company',)
    search_fields = ('company', 'position_en', 'description_en')
    ordering = ('order', '-id')


@admin.register(Education)
class EducationAdmin(ModelAdmin):
    list_display = ('institution_en', 'specialty_en', 'years_en', 'order')
    search_fields = ('institution_en', 'specialty_en')
    ordering = ('order', '-id')
