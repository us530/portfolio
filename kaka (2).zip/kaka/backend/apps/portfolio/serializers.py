from rest_framework import serializers
from .models import SkillCategory, Skill, Project

class SkillCategorySerializer(serializers.ModelSerializer):
    cat = serializers.SerializerMethodField()
    items = serializers.SerializerMethodField()

    class Meta:
        model = SkillCategory
        fields = ('cat', 'color', 'items')

    def get_cat(self, obj):
        lang = self.context.get('lang', 'en')
        if lang == 'ru' and obj.name_ru:
            return obj.name_ru
        if lang == 'uz' and obj.name_uz:
            return obj.name_uz
        return obj.name_en

    def get_items(self, obj):
        # Return a list of skill names sorted by order
        return list(obj.skills.all().values_list('name', flat=True))


class ProjectSerializer(serializers.ModelSerializer):
    cat = serializers.CharField(source='category')
    desc = serializers.SerializerMethodField()
    img = serializers.SerializerMethodField()
    features = serializers.SerializerMethodField()
    quote = serializers.SerializerMethodField()
    client = serializers.SerializerMethodField()

    class Meta:
        model = Project
        fields = (
            'id', 'cat', 'name', 'desc', 'img', 'colors', 'tech',
            'features', 'quote', 'client', 'live_demo_url', 'github_url'
        )

    def get_desc(self, obj):
        lang = self.context.get('lang', 'en')
        if lang == 'ru' and obj.desc_ru:
            return obj.desc_ru
        if lang == 'uz' and obj.desc_uz:
            return obj.desc_uz
        return obj.desc_en

    def get_img(self, obj):
        if obj.image:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.image.url)
            return obj.image.url
        return obj.image_url or ''

    def get_features(self, obj):
        lang = self.context.get('lang', 'en')
        if lang == 'ru' and obj.features_ru:
            return obj.features_ru
        if lang == 'uz' and obj.features_uz:
            return obj.features_uz
        return obj.features_en

    def get_quote(self, obj):
        lang = self.context.get('lang', 'en')
        if lang == 'ru' and obj.quote_ru:
            return obj.quote_ru
        if lang == 'uz' and obj.quote_uz:
            return obj.quote_uz
        return obj.quote_en

    def get_client(self, obj):
        lang = self.context.get('lang', 'en')
        if lang == 'ru' and obj.client_ru:
            return obj.client_ru
        if lang == 'uz' and obj.client_uz:
            return obj.client_uz
        return obj.client_en
