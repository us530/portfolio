from django.contrib import admin
from unfold.admin import ModelAdmin

from .models import QuotationRequest


@admin.register(QuotationRequest)
class QuotationRequestAdmin(ModelAdmin):
    list_display = ('name', 'email', 'service_type', 'budget', 'timeline', 'created_at')
    list_filter = ('service_type', 'created_at')
    search_fields = ('name', 'email', 'description', 'message')
    readonly_fields = ('created_at',)
    ordering = ('-created_at',)
