import logging

from celery import shared_task
from django.conf import settings
from django.core.mail import send_mail

from core.telegram import escape_html, send_telegram_message
from .models import QuotationRequest

logger = logging.getLogger(__name__)


def format_quotation_telegram_message(request):
    attachment = request.attachment.url if request.attachment else 'None'
    return (
        '💼 <b>New Quotation Request!</b>\n\n'
        f'👤 <b>Name:</b> {escape_html(request.name)}\n'
        f'📧 <b>Email:</b> {escape_html(request.email)}\n'
        f'📞 <b>Phone:</b> {escape_html(request.phone)}\n'
        f'🏢 <b>Company:</b> {escape_html(request.company)}\n'
        f'🛠️ <b>Service:</b> {escape_html(request.service_type)}\n'
        f'💰 <b>Budget:</b> {escape_html(request.budget)}\n'
        f'⏱️ <b>Timeline:</b> {escape_html(request.timeline)}\n\n'
        f'📝 <b>Description:</b>\n{escape_html(request.description)}\n\n'
        f'💬 <b>Message:</b>\n{escape_html(request.message)}\n\n'
        f'📎 <b>Attachment:</b> {escape_html(attachment)}'
    )


@shared_task
def send_quotation_request_notifications(request_id):
    try:
        request = QuotationRequest.objects.get(id=request_id)
    except QuotationRequest.DoesNotExist:
        logger.error('QuotationRequest with ID %s does not exist.', request_id)
        return

    email_subject = f'New Quotation Request from {request.name}'
    email_body = f"""
You received a new quotation request on Khasanov.dev:

Name: {request.name}
Email: {request.email}
Phone: {request.phone or 'N/A'}
Company: {request.company or 'N/A'}
Service Type: {request.service_type or 'N/A'}
Budget: {request.budget or 'N/A'}
Timeline: {request.timeline or 'N/A'}

Description:
{request.description or 'No description provided.'}

Message:
{request.message or 'No message provided.'}

Attachment: {request.attachment.url if request.attachment else 'No attachment uploaded'}
Created At: {request.created_at}
"""
    try:
        send_mail(
            subject=email_subject,
            message=email_body,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[getattr(settings, 'EMAIL_HOST_USER', '')],
            fail_silently=True,
        )
        logger.info('Quotation notification email sent successfully.')
    except Exception as exc:
        logger.error('Failed to send quotation notification email: %s', exc)

    send_telegram_message(format_quotation_telegram_message(request))
