from rest_framework import serializers

from .models import QuotationRequest


class QuotationRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuotationRequest
        fields = (
            'id', 'name', 'email', 'phone', 'company', 'service_type',
            'budget', 'timeline', 'description', 'attachment', 'message',
            'created_at',
        )
        read_only_fields = ('id', 'created_at')
