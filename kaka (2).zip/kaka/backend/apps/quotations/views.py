from rest_framework import permissions, viewsets

from .models import QuotationRequest
from .serializers import QuotationRequestSerializer
from .tasks import send_quotation_request_notifications


class QuotationRequestViewSet(viewsets.ModelViewSet):
    queryset = QuotationRequest.objects.all()
    serializer_class = QuotationRequestSerializer

    def get_permissions(self):
        if self.action == 'create':
            return [permissions.AllowAny()]
        return [permissions.IsAdminUser()]

    def perform_create(self, serializer):
        instance = serializer.save()
        send_quotation_request_notifications.delay(instance.id)
