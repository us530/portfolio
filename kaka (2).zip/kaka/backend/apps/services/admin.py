from django.contrib import admin
from unfold.admin import ModelAdmin
from .models import Service

@admin.register(Service)
class ServiceAdmin(ModelAdmin):
    list_display = ('title_en', 'icon', 'price', 'order')
    list_filter = ('icon',)
    search_fields = ('title_en', 'title_ru', 'title_uz', 'desc_en')
    fieldsets = (
        ('Basic Configuration', {
            'fields': ('icon', 'price', 'order')
        }),
        ('Translations (English)', {
            'fields': ('title_en', 'desc_en', 'tags_en')
        }),
        ('Translations (Russian)', {
            'fields': ('title_ru', 'desc_ru', 'tags_ru')
        }),
        ('Translations (Uzbek)', {
            'fields': ('title_uz', 'desc_uz', 'tags_uz')
        }),
    )
