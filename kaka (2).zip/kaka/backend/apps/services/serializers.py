from rest_framework import serializers
from .models import Service

class ServiceSerializer(serializers.ModelSerializer):
    title = serializers.SerializerMethodField()
    desc = serializers.SerializerMethodField()
    tags = serializers.SerializerMethodField()

    class Meta:
        model = Service
        fields = ('id', 'icon', 'title', 'desc', 'tags')

    def get_title(self, obj):
        lang = self.context.get('lang', 'en')
        if lang == 'ru' and obj.title_ru:
            return obj.title_ru
        if lang == 'uz' and obj.title_uz:
            return obj.title_uz
        return obj.title_en

    def get_desc(self, obj):
        lang = self.context.get('lang', 'en')
        if lang == 'ru' and obj.desc_ru:
            return obj.desc_ru
        if lang == 'uz' and obj.desc_uz:
            return obj.desc_uz
        return obj.desc_en

    def get_tags(self, obj):
        lang = self.context.get('lang', 'en')
        if lang == 'ru' and obj.tags_ru:
            return obj.tags_ru
        if lang == 'uz' and obj.tags_uz:
            return obj.tags_uz
        return obj.tags_en
