from django.db import models

class Service(models.Model):
    ICON_CHOICES = [
        ('globe', 'Globe (Web Development)'),
        ('layers', 'Layers (SaaS/Apps)'),
        ('phone', 'Phone (Mobile Apps)'),
        ('server', 'Server (Backend & APIs)'),
        ('cpu', 'CPU (AI & Automation)'),
        ('send', 'Send (Telegram Bots)'),
        ('database', 'Database (Cloud/Databases)'),
        ('shield', 'Shield (Security/Optimization)'),
    ]
    
    icon = models.CharField(max_length=50, choices=ICON_CHOICES, default='globe')
    
    title_en = models.CharField(max_length=150)
    title_ru = models.CharField(max_length=150, blank=True)
    title_uz = models.CharField(max_length=150, blank=True)
    
    desc_en = models.TextField()
    desc_ru = models.TextField(blank=True)
    desc_uz = models.TextField(blank=True)
    
    tags_en = models.JSONField(default=list, help_text="List of tag strings in English")
    tags_ru = models.JSONField(default=list, blank=True, help_text="List of tag strings in Russian")
    tags_uz = models.JSONField(default=list, blank=True, help_text="List of tag strings in Uzbek")
    
    price = models.CharField(max_length=100, blank=True, null=True, help_text="e.g. from $1,000")
    
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['order', 'title_en']

    def __str__(self):
        return self.title_en
