from rest_framework import viewsets, permissions, status
from rest_framework.response import Response
from .models import ContactRequest
from .serializers import ContactRequestSerializer
from .tasks import send_contact_request_notifications

class ContactRequestViewSet(viewsets.ModelViewSet):
    queryset = ContactRequest.objects.all()
    serializer_class = ContactRequestSerializer

    def get_permissions(self):
        if self.action == 'create':
            return [permissions.AllowAny()]
        return [permissions.IsAdminUser()]

    def perform_create(self, serializer):
        instance = serializer.save()
        # Trigger Celery notification task asynchronously
        send_contact_request_notifications.delay(instance.id)
