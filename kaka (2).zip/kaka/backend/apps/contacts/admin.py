from django.contrib import admin
from django.utils.safestring import mark_safe
from unfold.admin import ModelAdmin
from .models import ContactRequest

@admin.register(ContactRequest)
class ContactRequestAdmin(ModelAdmin):
    list_display = ('name', 'email', 'phone', 'budget', 'project_type', 'status_badge', 'created_at')
    list_filter = ('status', 'project_type', 'created_at')
    search_fields = ('name', 'email', 'project_description', 'message')
    readonly_fields = ('created_at',)
    ordering = ('-created_at',)
    
    actions = ['mark_as_read', 'mark_as_replied']

    def status_badge(self, obj):
        colors = {
            'New': 'background-color: rgba(239, 68, 68, 0.15); color: rgb(239, 68, 68); border: 1px solid rgba(239, 68, 68, 0.3);',
            'Read': 'background-color: rgba(59, 130, 246, 0.15); color: rgb(59, 130, 246); border: 1px solid rgba(59, 130, 246, 0.3);',
            'Replied': 'background-color: rgba(16, 185, 129, 0.15); color: rgb(16, 185, 129); border: 1px solid rgba(16, 185, 129, 0.3);',
        }
        style = colors.get(obj.status, 'background-color: rgba(156, 163, 175, 0.15); color: rgb(156, 163, 175);')
        return mark_safe(f'<span style="padding: 4px 10px; border-radius: 9999px; font-weight: 600; font-size: 0.75rem; text-transform: uppercase; {style}">{obj.status}</span>')
    status_badge.short_description = "Status"

    def mark_as_read(self, request, queryset):
        rows_updated = queryset.update(status='Read')
        self.message_user(request, f"{rows_updated} requests successfully marked as Read.")
    mark_as_read.short_description = "Mark selected as Read"

    def mark_as_replied(self, request, queryset):
        rows_updated = queryset.update(status='Replied')
        self.message_user(request, f"{rows_updated} requests successfully marked as Replied.")
    mark_as_replied.short_description = "Mark selected as Replied"
