from django.db import migrations

def create_groups(apps, schema_editor):
    Group = apps.get_model('auth', 'Group')
    Permission = apps.get_model('auth', 'Permission')
    ContentType = apps.get_model('contenttypes', 'ContentType')

    # 1. Create Groups
    super_admin_group, _ = Group.objects.get_or_create(name='Super Admin')
    admin_group, _ = Group.objects.get_or_create(name='Admin')
    editor_group, _ = Group.objects.get_or_create(name='Editor')

    # Helper function to get permissions
    def get_perms(app_label, model_names, actions):
        perms = []
        for model in model_names:
            try:
                ct = ContentType.objects.get(app_label=app_label, model=model.lower())
                for action in actions:
                    codename = f"{action}_{model.lower()}"
                    perm = Permission.objects.get(content_type=ct, codename=codename)
                    perms.append(perm)
            except (ContentType.DoesNotExist, Permission.DoesNotExist):
                continue
        return perms

    # Setup content structures
    portfolio_models = ['SkillCategory', 'Skill', 'Project', 'ProjectImage', 'Certificate', 'Experience', 'Education']
    services_models = ['Service']
    testimonials_models = ['Testimonial']
    faq_models = ['FAQ']
    bookings_models = ['Booking']
    contacts_models = ['ContactRequest']
    quotations_models = ['QuotationRequest']
    custom_orders_models = ['CustomOrder']
    main_models = ['HeroSection', 'About', 'ContactInfo', 'SiteSettings']

    # Admin Permissions: CRUD on everything except user auth/security configurations
    admin_perms = []
    admin_perms.extend(get_perms('portfolio', portfolio_models, ['add', 'change', 'delete', 'view']))
    admin_perms.extend(get_perms('services', services_models, ['add', 'change', 'delete', 'view']))
    admin_perms.extend(get_perms('testimonials', testimonials_models, ['add', 'change', 'delete', 'view']))
    admin_perms.extend(get_perms('faq', faq_models, ['add', 'change', 'delete', 'view']))
    admin_perms.extend(get_perms('bookings', bookings_models, ['add', 'change', 'delete', 'view']))
    admin_perms.extend(get_perms('contacts', contacts_models, ['add', 'change', 'delete', 'view']))
    admin_perms.extend(get_perms('quotations', quotations_models, ['add', 'change', 'delete', 'view']))
    admin_perms.extend(get_perms('custom_orders', custom_orders_models, ['add', 'change', 'delete', 'view']))
    admin_perms.extend(get_perms('main', main_models, ['add', 'change', 'delete', 'view']))
    
    admin_group.permissions.set(admin_perms)

    # Editor Permissions: Create and Update (no delete) on portfolio, testimonials, services, and main layout config
    editor_perms = []
    editor_perms.extend(get_perms('portfolio', portfolio_models, ['add', 'change', 'view']))
    editor_perms.extend(get_perms('services', services_models, ['add', 'change', 'view']))
    editor_perms.extend(get_perms('testimonials', testimonials_models, ['add', 'change', 'view']))
    editor_perms.extend(get_perms('faq', faq_models, ['add', 'change', 'view']))
    editor_perms.extend(get_perms('main', main_models, ['add', 'change', 'view']))

    editor_group.permissions.set(editor_perms)

def remove_groups(apps, schema_editor):
    Group = apps.get_model('auth', 'Group')
    Group.objects.filter(name__in=['Super Admin', 'Admin', 'Editor']).delete()

class Migration(migrations.Migration):

    dependencies = [
        ('users', '0001_initial'),
        ('auth', '__first__'),
        ('contenttypes', '__first__'),
        ('main', '0001_initial'),
        ('portfolio', '0002_certificate_education_experience_and_more'),
        ('services', '0002_service_price'),
        ('testimonials', '0002_testimonial_image_testimonial_rating'),
        ('contacts', '0002_contactrequest_status'),
    ]

    operations = [
        migrations.RunPython(create_groups, remove_groups),
    ]
