import os
import requests
from django.conf import settings
from django.contrib.auth import get_user_model
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from rest_framework_simplejwt.tokens import RefreshToken
from .serializers import UserSerializer

User = get_user_model()

def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)
    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }

class UserProfileView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        serializer = UserSerializer(request.user)
        return Response(serializer.data)


class GoogleLoginView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        access_token = request.data.get('access_token')
        code = request.data.get('code')
        
        if not access_token and not code:
            return Response({'error': 'Either access_token or code is required'}, status=status.HTTP_400_BAD_REQUEST)
            
        # Exchange auth code if access_token is not direct
        if code:
            token_url = "https://oauth2.googleapis.com/token"
            data = {
                'code': code,
                'client_id': os.getenv('GOOGLE_CLIENT_ID', ''),
                'client_secret': os.getenv('GOOGLE_CLIENT_SECRET', ''),
                'redirect_uri': os.getenv('GOOGLE_REDIRECT_URI', 'postmessage'),
                'grant_type': 'authorization_code',
            }
            r = requests.post(token_url, data=data, timeout=10)
            token_data = r.json()
            if 'error' in token_data:
                return Response({'error': 'Failed to exchange Google auth code', 'details': token_data}, status=status.HTTP_400_BAD_REQUEST)
            access_token = token_data.get('access_token')

        # Fetch user info from Google API
        userinfo_url = "https://www.googleapis.com/oauth2/v3/userinfo"
        headers = {'Authorization': f'Bearer {access_token}'}
        userinfo_response = requests.get(userinfo_url, headers=headers, timeout=10)
        
        if userinfo_response.status_code != 200:
            return Response({'error': 'Invalid Google access token'}, status=status.HTTP_400_BAD_REQUEST)
            
        user_info = userinfo_response.json()
        email = user_info.get('email')
        google_id = user_info.get('sub')
        first_name = user_info.get('given_name', '')
        last_name = user_info.get('family_name', '')
        avatar = user_info.get('picture', '')

        if not email:
            return Response({'error': 'Google account must have an associated email address'}, status=status.HTTP_400_BAD_REQUEST)

        # Get or create user
        user, created = User.objects.get_or_create(
            google_id=google_id,
            defaults={
                'email': email,
                'username': email.split('@')[0] + '_google',
                'first_name': first_name,
                'last_name': last_name,
                'avatar': avatar,
            }
        )
        
        if not created and not user.google_id:
            user.google_id = google_id
            user.save()

        tokens = get_tokens_for_user(user)
        return Response({
            'user': UserSerializer(user).data,
            'tokens': tokens
        }, status=status.HTTP_200_OK)


class GitHubLoginView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        code = request.data.get('code')
        if not code:
            return Response({'error': 'Code is required'}, status=status.HTTP_400_BAD_REQUEST)

        # Exchange auth code for GitHub access token
        token_url = 'https://github.com/login/oauth/access_token'
        headers = {'Accept': 'application/json'}
        data = {
            'client_id': os.getenv('GITHUB_CLIENT_ID', ''),
            'client_secret': os.getenv('GITHUB_CLIENT_SECRET', ''),
            'code': code,
        }
        
        token_response = requests.post(token_url, data=data, headers=headers, timeout=10)
        token_json = token_response.json()
        access_token = token_json.get('access_token')

        if not access_token:
            return Response({'error': 'Invalid code or failed to authenticate with GitHub', 'details': token_json}, status=status.HTTP_400_BAD_REQUEST)

        # Fetch user info
        user_url = 'https://api.github.com/user'
        user_headers = {'Authorization': f'token {access_token}'}
        user_response = requests.get(user_url, headers=user_headers, timeout=10)
        
        if user_response.status_code != 200:
            return Response({'error': 'Failed to fetch user data from GitHub'}, status=status.HTTP_400_BAD_REQUEST)

        user_data = user_response.json()
        github_id = str(user_data.get('id'))
        username = user_data.get('login')
        avatar = user_data.get('avatar_url')
        name = user_data.get('name') or ''
        email = user_data.get('email')

        # If email is private, fetch public email list
        if not email:
            emails_response = requests.get('https://api.github.com/user/emails', headers=user_headers, timeout=10)
            if emails_response.status_code == 200:
                emails = emails_response.json()
                primary_email = next((e for e in emails if e.get('primary') and e.get('verified')), None)
                if primary_email:
                    email = primary_email.get('email')
                elif emails:
                    email = emails[0].get('email')

        if not email:
            email = f'{username}@github.placeholder'

        # Get or create user
        user, created = User.objects.get_or_create(
            github_id=github_id,
            defaults={
                'email': email,
                'username': username + '_github',
                'first_name': name.split(' ')[0] if name else '',
                'last_name': ' '.join(name.split(' ')[1:]) if name and len(name.split(' ')) > 1 else '',
                'avatar': avatar,
            }
        )

        if not created and not user.github_id:
            user.github_id = github_id
            user.save()

        tokens = get_tokens_for_user(user)
        return Response({
            'user': UserSerializer(user).data,
            'tokens': tokens
        }, status=status.HTTP_200_OK)
