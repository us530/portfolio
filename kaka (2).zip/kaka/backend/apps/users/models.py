from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    # Additional fields if needed for custom social profiles
    google_id = models.CharField(max_length=255, blank=True, null=True, unique=True)
    github_id = models.CharField(max_length=255, blank=True, null=True, unique=True)
    avatar = models.URLField(max_length=500, blank=True, null=True)

    def __str__(self):
        return self.username
