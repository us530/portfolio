from django.db import models

class Testimonial(models.Model):
    name = models.CharField(max_length=150)
    initials = models.CharField(max_length=5, help_text="Initials to display on avatar, e.g. AB")
    colors = models.JSONField(default=list, help_text="List of two hex colors for avatar gradient, e.g. ['#3b7cff', '#6c3df0']")
    image = models.ImageField(upload_to='testimonials/', blank=True, null=True)
    rating = models.PositiveIntegerField(default=5, help_text="Rating from 1 to 5")
    
    role_en = models.CharField(max_length=200)
    role_ru = models.CharField(max_length=200, blank=True)
    role_uz = models.CharField(max_length=200, blank=True)
    
    quote_en = models.TextField()
    quote_ru = models.TextField(blank=True)
    quote_uz = models.TextField(blank=True)
    
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['order', 'name']

    def __str__(self):
        return f"{self.name} ({self.role_en})"
