from django.contrib import admin
from django.utils.safestring import mark_safe
from unfold.admin import ModelAdmin
from .models import Testimonial

@admin.register(Testimonial)
class TestimonialAdmin(ModelAdmin):
    list_display = ('name', 'role_en', 'star_rating', 'image_preview', 'order')
    search_fields = ('name', 'role_en', 'role_ru', 'role_uz', 'quote_en')
    readonly_fields = ('image_preview',)
    list_filter = ('rating',)

    fieldsets = (
        ('Basic Configuration', {
            'fields': ('name', 'initials', 'colors', 'image', 'image_preview', 'rating', 'order')
        }),
        ('Translations (English)', {
            'fields': ('role_en', 'quote_en')
        }),
        ('Translations (Russian)', {
            'fields': ('role_ru', 'quote_ru')
        }),
        ('Translations (Uzbek)', {
            'fields': ('role_uz', 'quote_uz')
        }),
    )

    def star_rating(self, obj):
        return "★" * min(max(obj.rating, 1), 5)
    star_rating.short_description = "Rating"

    def image_preview(self, obj):
        if obj.image:
            return mark_safe(f'<img src="{obj.image.url}" style="max-height: 50px; border-radius: 50%;" />')
        return "No image"
    image_preview.short_description = "Avatar Image Preview"
