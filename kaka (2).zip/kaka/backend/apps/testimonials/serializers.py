from rest_framework import serializers
from .models import Testimonial

class TestimonialSerializer(serializers.ModelSerializer):
    role = serializers.SerializerMethodField()
    quote = serializers.SerializerMethodField()
    init = serializers.CharField(source='initials')

    class Meta:
        model = Testimonial
        fields = ('id', 'name', 'role', 'quote', 'init', 'colors')

    def get_role(self, obj):
        lang = self.context.get('lang', 'en')
        if lang == 'ru' and obj.role_ru:
            return obj.role_ru
        if lang == 'uz' and obj.role_uz:
            return obj.role_uz
        return obj.role_en

    def get_quote(self, obj):
        lang = self.context.get('lang', 'en')
        if lang == 'ru' and obj.quote_ru:
            return obj.quote_ru
        if lang == 'uz' and obj.quote_uz:
            return obj.quote_uz
        return obj.quote_en
