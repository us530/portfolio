from .base import *
from dotenv import load_dotenv

# Load local environment variables
load_dotenv(os.path.join(BASE_DIR, '.env'))

DEBUG = True

ALLOWED_HOSTS = ['*']

CORS_ALLOW_ALL_ORIGINS = True

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# Email Backend for Local Development
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

# Telegram Bot configuration (values loaded from .env — never hardcode the token)
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '')
TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID', '')
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', '')

# Run Celery tasks synchronously in local dev so notifications work without Redis
CELERY_TASK_ALWAYS_EAGER = os.getenv('CELERY_TASK_ALWAYS_EAGER', 'True') == 'True'
CELERY_TASK_EAGER_PROPAGATES = True
