import html
import logging

import requests
from django.conf import settings

logger = logging.getLogger(__name__)


def escape_html(value):
    if value is None or value == '':
        return 'N/A'
    return html.escape(str(value))


def send_telegram_message(text, parse_mode='HTML'):
    bot_token = settings.TELEGRAM_BOT_TOKEN
    chat_id = settings.TELEGRAM_CHAT_ID

    if not bot_token or not chat_id:
        logger.warning('Telegram Bot Token or Chat ID not configured. Skipping notification.')
        return False

    url = f'https://api.telegram.org/bot{bot_token}/sendMessage'
    try:
        response = requests.post(
            url,
            data={
                'chat_id': chat_id,
                'text': text,
                'parse_mode': parse_mode,
            },
            timeout=15,
        )
        if response.status_code == 200:
            logger.info('Telegram notification sent successfully.')
            return True
        logger.error('Telegram notification returned non-200 code: %s', response.text)
    except Exception as exc:
        logger.error('Failed to send Telegram notification: %s', exc)
    return False
