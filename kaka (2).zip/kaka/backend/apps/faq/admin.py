from django.contrib import admin
from unfold.admin import ModelAdmin
from .models import FAQ

@admin.register(FAQ)
class FAQAdmin(ModelAdmin):
    list_display = ('question_en', 'order')
    search_fields = ('question_en', 'question_ru', 'question_uz', 'answer_en')
    fieldsets = (
        ('Basic Configuration', {
            'fields': ('order',)
        }),
        ('Translations (English)', {
            'fields': ('question_en', 'answer_en')
        }),
        ('Translations (Russian)', {
            'fields': ('question_ru', 'answer_ru')
        }),
        ('Translations (Uzbek)', {
            'fields': ('question_uz', 'answer_uz')
        }),
    )
