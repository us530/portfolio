from django.db import models

class FAQ(models.Model):
    question_en = models.CharField(max_length=255)
    question_ru = models.CharField(max_length=255, blank=True)
    question_uz = models.CharField(max_length=255, blank=True)
    
    answer_en = models.TextField()
    answer_ru = models.TextField(blank=True)
    answer_uz = models.TextField(blank=True)
    
    order = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name = "FAQ"
        verbose_name_plural = "FAQs"
        ordering = ['order', 'id']

    def __str__(self):
        return self.question_en
