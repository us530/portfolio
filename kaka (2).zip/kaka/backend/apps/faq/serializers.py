from rest_framework import serializers
from .models import FAQ

class FAQSerializer(serializers.ModelSerializer):
    q = serializers.SerializerMethodField()
    a = serializers.SerializerMethodField()

    class Meta:
        model = FAQ
        fields = ('id', 'q', 'a')

    def get_q(self, obj):
        lang = self.context.get('lang', 'en')
        if lang == 'ru' and obj.question_ru:
            return obj.question_ru
        if lang == 'uz' and obj.question_uz:
            return obj.question_uz
        return obj.question_en

    def get_a(self, obj):
        lang = self.context.get('lang', 'en')
        if lang == 'ru' and obj.answer_ru:
            return obj.answer_ru
        if lang == 'uz' and obj.answer_uz:
            return obj.answer_uz
        return obj.answer_en
